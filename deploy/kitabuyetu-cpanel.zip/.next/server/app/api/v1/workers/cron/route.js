"use strict";(()=>{var e={};e.id=6039,e.ids=[6039],e.modules={41495:e=>{e.exports=require("ioredis")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},45184:e=>{e.exports=require("nodemailer")},35900:e=>{e.exports=require("pg")},27689:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>O,patchFetch:()=>v,requestAsyncStorage:()=>R,routeModule:()=>A,serverHooks:()=>S,staticGenerationAsyncStorage:()=>f});var a={};r.r(a),r.d(a,{POST:()=>T});var i=r(49303),n=r(88716),o=r(60670),s=r(87070),u=r(97395),m=r(58513);async function l(){let{rows:e}=await (0,u.xh)(e=>e.query(`SELECT * FROM email_schedules
       WHERE is_active = true AND next_run_at <= NOW()
       ORDER BY next_run_at ASC
       LIMIT 100`,[])),t=0,r=0;for(let a of e)try{let e=a.variables??{};if(await (0,m.Al)({templateKey:a.template_key,to:a.recipient_email,vars:e,groupId:a.group_id,referenceId:a.reference_id,referenceType:a.reference_type}),"once"===a.schedule_type)await (0,u.xh)(e=>e.query("UPDATE email_schedules SET is_active=false, last_run_at=NOW() WHERE id=$1",[a.id]));else{let e=function(e,t){let r=new Date(t);switch(e){case"daily":default:r.setDate(r.getDate()+1);break;case"weekly":r.setDate(r.getDate()+7);break;case"monthly":r.setMonth(r.getMonth()+1)}return r}(a.schedule_type,new Date(a.next_run_at));await (0,u.xh)(t=>t.query("UPDATE email_schedules SET last_run_at=NOW(), next_run_at=$1 WHERE id=$2",[e.toISOString(),a.id]))}t++}catch(e){console.error("[scheduler] Failed to send scheduled email",a.id,e),r++}return{processed:t,failed:r}}async function c(){let{rows:e}=await (0,u.xh)(e=>e.query(`SELECT * FROM email_logs
       WHERE status = 'failed'
         AND created_at >= NOW() - INTERVAL '24 hours'
         AND created_at <= NOW() - INTERVAL '5 minutes'
       ORDER BY created_at ASC
       LIMIT 50`,[])),t=0;for(let r of e)if(r.template_key)try{await (0,m.Al)({templateKey:r.template_key,to:r.to,vars:{},groupId:r.group_id,referenceId:r.reference_id,referenceType:r.reference_type}),t++}catch{}return{retried:t}}async function d(){let{rows:e}=await (0,u.xh)(e=>e.query(`SELECT m.id, m.full_name, m.email, g.name AS group_name, gm.group_id
       FROM members m
       JOIN group_members gm ON gm.member_id = m.id
       JOIN groups g ON g.id = gm.group_id
       WHERE m.email IS NOT NULL
         AND m.date_of_birth IS NOT NULL
         AND EXTRACT(MONTH FROM m.date_of_birth) = EXTRACT(MONTH FROM CURRENT_DATE)
         AND EXTRACT(DAY   FROM m.date_of_birth) = EXTRACT(DAY   FROM CURRENT_DATE)`,[]));for(let t of e)await (0,m.Jf)({templateKey:"birthday",to:t.email,vars:{memberName:t.full_name,groupName:t.group_name},groupId:t.group_id,userId:t.id,priority:"low",referenceType:"member"}).catch(()=>{})}let _=process.env.MPESA_SHORTCODE??"",p=process.env.EMAIL_ADMIN??"admin@kitabuyetu.com",E=`
  WITH admin_contact AS (
    SELECT gm.group_id,
           m.first_name || ' ' || m.last_name AS full_name,
           m.email
    FROM group_members gm
    JOIN members m ON m.id = gm.member_id
    WHERE gm.is_active = true
      AND gm.role IN ('group_admin','treasurer')
      AND m.email IS NOT NULL
    ORDER BY
      CASE gm.role WHEN 'group_admin' THEN 0 ELSE 1 END,
      gm.joined_at ASC
  )
`;async function g(){let{rows:e}=await (0,u.xh)(e=>e.query(`${E}
       SELECT i.*,
              g.name AS group_name,
              COALESCE(ac.full_name, g.name)  AS recipient_name,
              COALESCE(ac.email,    g.email)  AS recipient_email,
              EXTRACT(DAY FROM NOW() - i.due_date)::int AS days_overdue
       FROM invoices i
       JOIN groups g ON g.id = i.group_id
       LEFT JOIN LATERAL (
         SELECT full_name, email FROM admin_contact
         WHERE group_id = i.group_id LIMIT 1
       ) ac ON true
       WHERE i.status = 'pending'
         AND i.paid_amount < i.total_amount
         AND i.due_date < CURRENT_DATE
         AND (i.overdue_notice_level < 3 OR i.overdue_notice_level IS NULL)
       ORDER BY i.due_date ASC`,[]));for(let r of e){var t;let e=r.days_overdue??0,a=r.overdue_notice_level??0,i=e>=15?3:e>=8?2:e>=3?1:0;if(0===i||i<=a||!r.recipient_email)continue;let n=parseFloat(r.total_amount)-parseFloat(r.paid_amount),o=`invoice_overdue_${i}`,s={invoiceNumber:r.invoice_number,recipientName:r.recipient_name,groupName:r.group_name,dueDate:(t=r.due_date)?new Date(t).toLocaleDateString("en-KE",{day:"2-digit",month:"short",year:"numeric"}):"",amountDue:N(n),daysOverdue:String(e),shortcode:_,adminEmail:p};await (0,m.Al)({templateKey:o,to:r.recipient_email,vars:s,groupId:r.group_id,referenceId:r.id,referenceType:"invoice"}).catch(()=>{}),i>=2&&await (0,m.Al)({templateKey:o,to:p,vars:{...s,recipientName:`[ADMIN CC] ${r.recipient_name} <${r.recipient_email}>`},groupId:r.group_id,referenceId:r.id,referenceType:"invoice"}).catch(()=>{}),await (0,u.xh)(e=>e.query(`UPDATE invoices
         SET overdue_notice_level = $1, last_reminder_sent_at = NOW()
         WHERE id = $2`,[i,r.id])).catch(()=>{})}}async function y(){let{rows:e}=await (0,u.xh)(e=>e.query(`SELECT s.*,
              m.email AS recipient_email,
              m.first_name || ' ' || m.last_name AS recipient_name
       FROM invoice_schedules s
       LEFT JOIN members m ON m.id = s.recipient_user_id
       WHERE s.is_active = true AND s.next_run_at <= NOW()`,[]));for(let t of e)try{let{rows:e}=await (0,u.xh)(e=>e.query("SELECT id FROM billing_accounts WHERE group_id = $1 LIMIT 1",[t.group_id]));if(!e[0]){console.error("[billing] No billing account for group",t.group_id);continue}let r=e[0].id,{rows:[a]}=await (0,u.xh)(e=>e.query(`INSERT INTO invoices
             (group_id, billing_account_id, invoice_number,
              invoice_date, due_date,
              subtotal, tax_amount, total_amount, status, notes)
           VALUES (
             $1, $2,
             'INV-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || SUBSTR(gen_random_uuid()::text, 1, 6),
             CURRENT_DATE,
             (CURRENT_DATE + INTERVAL '30 days')::date,
             $3, 0, $3, 'pending', $4
           )
           RETURNING id`,[t.group_id,r,t.amount,t.description??null]));t.recipient_email&&await (0,m.Jf)({templateKey:"invoice",to:t.recipient_email,vars:{invoiceNumber:a.id,recipientName:t.recipient_name??"",amountDue:N(t.amount),shortcode:_,notes:t.description??""},groupId:t.group_id,referenceId:a.id,referenceType:"invoice"}),await (0,u.xh)(e=>e.query(`UPDATE invoice_schedules
           SET next_run_at = next_run_at + (frequency_days || ' days')::interval,
               last_run_at = NOW()
           WHERE id = $1`,[t.id]))}catch(e){console.error("[billing] Failed to process invoice schedule",t.id,e)}}function N(e){return Number(e).toLocaleString("en-KE",{minimumFractionDigits:2,maximumFractionDigits:2})}async function h(){let{rows:e}=await (0,u.xh)(e=>e.query("SELECT id, name FROM groups WHERE is_active = true",[])),t=new Date().toLocaleDateString("en-KE",{day:"2-digit",month:"short",year:"numeric"});for(let r of e){let[e,a,i,n]=await Promise.all([(0,u.xh)(e=>e.query(`SELECT COALESCE(SUM(amount),0) AS total FROM contributions
           WHERE group_id=$1 AND status='completed'
             AND created_at >= NOW() - INTERVAL '7 days'`,[r.id])),(0,u.xh)(e=>e.query(`SELECT COALESCE(SUM(principal_amount),0) AS total FROM loans
           WHERE group_id=$1 AND status='disbursed'
             AND disbursed_at >= NOW() - INTERVAL '7 days'`,[r.id])),(0,u.xh)(e=>e.query(`SELECT COALESCE(SUM(amount),0) AS total FROM loan_repayments
           WHERE group_id=$1 AND status='completed'
             AND created_at >= NOW() - INTERVAL '7 days'`,[r.id])),(0,u.xh)(e=>e.query(`SELECT COUNT(*) AS total FROM group_members
           WHERE group_id=$1 AND joined_at >= NOW() - INTERVAL '7 days'`,[r.id]))]),o={weekLabel:t,weekContributions:Number(e.rows[0]?.total??0).toLocaleString("en-KE",{minimumFractionDigits:2}),weekLoans:Number(a.rows[0]?.total??0).toLocaleString("en-KE",{minimumFractionDigits:2}),weekRepayments:Number(i.rows[0]?.total??0).toLocaleString("en-KE",{minimumFractionDigits:2}),newMembers:String(n.rows[0]?.total??0)},{rows:s}=await (0,u.xh)(e=>e.query(`SELECT m.email, m.full_name FROM members m
         JOIN group_members gm ON gm.member_id = m.id AND gm.group_id = $1
         WHERE m.email IS NOT NULL AND gm.role IN ('group_admin','treasurer')`,[r.id]));for(let e of s)await (0,m.Al)({templateKey:"weekly_summary",to:e.email,vars:{...o,recipientName:e.full_name,groupName:r.name},groupId:r.id,referenceType:"report"}).catch(()=>{})}}async function T(e){let t=process.env.WORKER_SECRET;if(t&&(e.headers.get("authorization")??"")!==`Bearer ${t}`)return s.NextResponse.json({error:"Forbidden"},{status:403});let r=new Date,a=r.getUTCHours(),i=r.getUTCDay(),n=r.getUTCDate(),o={};return o.schedules=await l().catch(e=>({error:e.message})),o.retries=await c().catch(e=>({error:e.message})),7===a&&(o.birthdays=await d().then(()=>"done").catch(e=>({error:e.message}))),9===a&&(o.overdueInvoices=await g().then(()=>"done").catch(e=>({error:e.message}))),6===a&&(o.recurringInvoices=await y().then(()=>"done").catch(e=>({error:e.message}))),1===i&&8===a&&(o.weeklySummaries=await h().then(()=>"done").catch(e=>({error:e.message}))),1===n&&8===a&&(o.monthlyStatements="triggered_externally"),s.NextResponse.json({success:!0,results:o,timestamp:r.toISOString()})}let A=new i.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/v1/workers/cron/route",pathname:"/api/v1/workers/cron",filename:"route",bundlePath:"app/api/v1/workers/cron/route"},resolvedPagePath:"C:\\Users\\Poly\\Desktop\\kitabuyetu\\app\\api\\v1\\workers\\cron\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:R,staticGenerationAsyncStorage:f,serverHooks:S}=A,O="/api/v1/workers/cron/route";function v(){return(0,o.patchFetch)({serverHooks:S,staticGenerationAsyncStorage:f})}},58513:(e,t,r)=>{r.d(t,{Al:()=>u,Jf:()=>m,wg:()=>l});var a=r(54371),i=r(95958),n=r(15446),o=r(3357),s=r(97395);async function u(e){var t;let r=n.K[e.templateKey],{subject:o,html:s}=await (0,i.SM)(e.templateKey,e.vars,e.groupId??null,e.locale??"en",r?.body).catch(async()=>{let t=await (0,i.w_)(e.groupId??null),r=`<p>${JSON.stringify(e.vars)}</p>`;return{subject:String(e.vars.subject??"Kitabu Yetu"),html:(0,i.Y)(r,t)}});return(0,a.P)({to:e.to,subject:o,html:s,from:e.from,replyTo:e.replyTo,attachments:e.attachments,groupId:e.groupId??void 0,userId:e.userId,templateKey:e.templateKey,category:(t=e.templateKey).startsWith("invoice")||t.startsWith("payment")||t.startsWith("receipt")?"billing":t.startsWith("loan")?"loan":t.startsWith("contribution")?"contribution":t.startsWith("newsletter")?"newsletter":t.startsWith("contact")?"contact":"welcome"===t||"otp"===t||"password_reset"===t?"auth":"transactional",referenceId:e.referenceId,referenceType:e.referenceType})}async function m(e){let t="high"===e.priority?"email:high":"low"===e.priority?"email:low":"email:send";return(0,o.SP)(t,{type:"templated",...e},{delayMs:e.delayMs,maxAttempts:5})}async function l(e){let{rows:t}=await (0,s.xh)(t=>t.query(`INSERT INTO email_schedules
         (group_id, name, template_key, recipient_email, variables,
          schedule_type, next_run_at, is_active, created_by, reference_id, reference_type)
       VALUES ($1,$2,$3,$4,$5,'once',$6,true,$7,$8,$9) RETURNING id`,[e.groupId??null,e.name??e.templateKey,e.templateKey,Array.isArray(e.to)?e.to[0]:e.to,JSON.stringify(e.vars),e.sendAt.toISOString(),e.userId??null,e.referenceId??null,e.referenceType??null]));return t[0].id}}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,5972,2591,2829],()=>r(27689));module.exports=a})();