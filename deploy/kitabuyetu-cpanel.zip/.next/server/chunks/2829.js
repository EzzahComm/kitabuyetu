"use strict";exports.id=2829,exports.ids=[2829],exports.modules={97395:(e,t,r)=>{r.d(t,{ZG:()=>l,pool:()=>a,withDb:()=>i,xh:()=>d});var o=r(35900);if(!process.env.DATABASE_URL)throw Error("DATABASE_URL environment variable is not set");let n=globalThis;n._kyPool||(n._kyPool=new o.Pool({connectionString:process.env.DATABASE_URL,max:3,idleTimeoutMillis:1e4,connectionTimeoutMillis:8e3,ssl:(process.env.DATABASE_URL?.includes("supabase.com")||process.env.DATABASE_URL?.includes("supabase.co"),{rejectUnauthorized:!1})}),n._kyPool.on("error",e=>{console.error("[pg pool] Unexpected error on idle client:",e)}));let a=n._kyPool;async function s(e,t){await e.query("SELECT set_config($1, $2, TRUE)",["app.current_user_id",t.userId]),await e.query("SELECT set_config($1, $2, TRUE)",["app.current_group_id",t.groupId]),await e.query("SELECT set_config($1, $2, TRUE)",["app.current_role",t.role]),t.ngoId&&await e.query("SELECT set_config($1, $2, TRUE)",["app.current_ngo_id",t.ngoId])}async function i(e,t){let r=await a.connect();try{await r.query("BEGIN"),await s(r,e);let o=await t(r);return await r.query("COMMIT"),o}catch(e){throw await r.query("ROLLBACK"),e}finally{r.release()}}async function l(e,t){return i(e,t)}async function d(e){let t=await a.connect();try{await t.query("BEGIN");let r=await e(t);return await t.query("COMMIT"),r}catch(e){throw await t.query("ROLLBACK"),e}finally{t.release()}}},54371:(e,t,r)=>{r.d(t,{P:()=>y});var o=r(82591),n=r(97395);let a=new o.R(process.env.RESEND_API_KEY);class s{async send(e){let t=e.from??process.env.EMAIL_FROM??"noreply@kitabuyetu.com",r=Array.isArray(e.to)?e.to:[e.to],o=null;try{let{rows:a}=await (0,n.xh)(o=>o.query(`INSERT INTO email_logs
             (group_id, user_id, template_key, category, "to", "from", subject,
              provider, status, reference_id, reference_type)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'resend','queued',$8,$9) RETURNING id`,[e.groupId??null,e.userId??null,e.templateKey??null,e.category??"transactional",r[0],t,e.subject,e.referenceId??null,e.referenceType??null]));o=a[0]?.id??null}catch{}try{let s=e.attachments?.map(e=>({filename:e.filename,content:Buffer.isBuffer(e.content)?e.content:Buffer.from(e.content,"base64")})),{data:i,error:l}=await a.emails.send({from:t,to:r,subject:e.subject,html:e.html,text:e.text,replyTo:e.replyTo,cc:e.cc?Array.isArray(e.cc)?e.cc:[e.cc]:void 0,bcc:e.bcc?Array.isArray(e.bcc)?e.bcc:[e.bcc]:void 0,attachments:s,tags:e.tags?Object.entries(e.tags).map(([e,t])=>({name:e,value:t})):void 0});if(l)throw Error(l.message);return o&&await (0,n.xh)(e=>e.query("UPDATE email_logs SET status='sent', provider_message_id=$1, sent_at=NOW() WHERE id=$2",[i?.id??null,o])).catch(()=>{}),{success:!0,messageId:i?.id,provider:this.name}}catch(t){let e=t instanceof Error?t.message:String(t);return o&&await (0,n.xh)(t=>t.query("UPDATE email_logs SET status='failed', error_message=$1 WHERE id=$2",[e,o])).catch(()=>{}),{success:!1,error:e,provider:this.name}}}constructor(){this.name="resend"}}var i=r(45184),l=r.n(i);class d{async send(e){let t=e.from??process.env.EMAIL_FROM??"noreply@kitabuyetu.com",r=Array.isArray(e.to)?e.to:[e.to],o=null;try{let{rows:a}=await (0,n.xh)(o=>o.query(`INSERT INTO email_logs
             (group_id, user_id, template_key, category, "to", "from", subject,
              provider, status, reference_id, reference_type)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'smtp','queued',$8,$9) RETURNING id`,[e.groupId??null,e.userId??null,e.templateKey??null,e.category??"transactional",r[0],t,e.subject,e.referenceId??null,e.referenceType??null]));o=a[0]?.id??null}catch{}try{let a=l().createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT??587),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}}),s=await a.sendMail({from:t,to:r.join(", "),subject:e.subject,html:e.html,text:e.text,replyTo:e.replyTo,cc:e.cc,bcc:e.bcc,attachments:e.attachments?.map(e=>({filename:e.filename,content:e.content,contentType:e.contentType}))});return o&&await (0,n.xh)(e=>e.query("UPDATE email_logs SET status='sent', provider_message_id=$1, sent_at=NOW() WHERE id=$2",[s.messageId??null,o])).catch(()=>{}),{success:!0,messageId:s.messageId,provider:this.name}}catch(t){let e=t instanceof Error?t.message:String(t);return o&&await (0,n.xh)(t=>t.query("UPDATE email_logs SET status='failed', error_message=$1 WHERE id=$2",[e,o])).catch(()=>{}),{success:!1,error:e,provider:this.name}}}constructor(){this.name="smtp"}}class p{async send(e){let t=process.env.SENDGRID_API_KEY??"",r=e.from??process.env.EMAIL_FROM??"noreply@kitabuyetu.com",o=Array.isArray(e.to)?e.to:[e.to],a=null;try{let{rows:t}=await (0,n.xh)(t=>t.query(`INSERT INTO email_logs
             (group_id, user_id, template_key, category, "to", "from", subject,
              provider, status, reference_id, reference_type)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'sendgrid','queued',$8,$9) RETURNING id`,[e.groupId??null,e.userId??null,e.templateKey??null,e.category??"transactional",o[0],r,e.subject,e.referenceId??null,e.referenceType??null]));a=t[0]?.id??null}catch{}try{let s={personalizations:[{to:o.map(e=>({email:e}))}],from:{email:r,name:process.env.EMAIL_FROM_NAME??"Kitabu Yetu"},subject:e.subject,content:[{type:"text/html",value:e.html??""}]};if(e.text&&s.content.unshift({type:"text/plain",value:e.text}),e.replyTo&&(s.reply_to={email:e.replyTo}),e.cc){let t=Array.isArray(e.cc)?e.cc:[e.cc];s.personalizations[0].cc=t.map(e=>({email:e}))}e.attachments?.length&&(s.attachments=e.attachments.map(e=>({filename:e.filename,content:Buffer.isBuffer(e.content)?e.content.toString("base64"):Buffer.from(e.content).toString("base64"),type:e.contentType??"application/octet-stream",disposition:"attachment"})));let i=await fetch("https://api.sendgrid.com/v3/mail/send",{method:"POST",headers:{Authorization:`Bearer ${t}`,"Content-Type":"application/json"},body:JSON.stringify(s)});if(!i.ok){let e=await i.text();throw Error(`SendGrid ${i.status}: ${e}`)}let l=i.headers.get("x-message-id")??void 0;return a&&await (0,n.xh)(e=>e.query("UPDATE email_logs SET status='sent', provider_message_id=$1, sent_at=NOW() WHERE id=$2",[l??null,a])).catch(()=>{}),{success:!0,messageId:l,provider:this.name}}catch(t){let e=t instanceof Error?t.message:String(t);return a&&await (0,n.xh)(t=>t.query("UPDATE email_logs SET status='failed', error_message=$1 WHERE id=$2",[e,a])).catch(()=>{}),{success:!1,error:e,provider:this.name}}}constructor(){this.name="sendgrid"}}class c{async send(e){let t=e.from??process.env.EMAIL_FROM??"noreply@kitabuyetu.com",r=Array.isArray(e.to)?e.to:[e.to],o=null;try{let{rows:a}=await (0,n.xh)(o=>o.query(`INSERT INTO email_logs
             (group_id, user_id, template_key, category, "to", "from", subject,
              provider, status, reference_id, reference_type)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'ses','queued',$8,$9) RETURNING id`,[e.groupId??null,e.userId??null,e.templateKey??null,e.category??"transactional",r[0],t,e.subject,e.referenceId??null,e.referenceType??null]));o=a[0]?.id??null}catch{}try{let a=l().createTransport({host:`email-smtp.${process.env.AWS_SES_REGION??"us-east-1"}.amazonaws.com`,port:587,secure:!1,auth:{user:process.env.AWS_SES_SMTP_USER,pass:process.env.AWS_SES_SMTP_PASSWORD}}),s=await a.sendMail({from:t,to:r.join(", "),subject:e.subject,html:e.html,text:e.text,replyTo:e.replyTo,cc:e.cc,bcc:e.bcc,attachments:e.attachments?.map(e=>({filename:e.filename,content:e.content,contentType:e.contentType}))});return o&&await (0,n.xh)(e=>e.query("UPDATE email_logs SET status='sent', provider_message_id=$1, sent_at=NOW() WHERE id=$2",[s.messageId??null,o])).catch(()=>{}),{success:!0,messageId:s.messageId,provider:this.name}}catch(t){let e=t instanceof Error?t.message:String(t);return o&&await (0,n.xh)(t=>t.query("UPDATE email_logs SET status='failed', error_message=$1 WHERE id=$2",[e,o])).catch(()=>{}),{success:!1,error:e,provider:this.name}}}constructor(){this.name="ses"}}class u{async send(e){let t=process.env.MAILGUN_API_KEY??"",r=process.env.MAILGUN_DOMAIN??"",o="eu"===(process.env.MAILGUN_REGION??"us")?`https://api.eu.mailgun.net/v3/${r}/messages`:`https://api.mailgun.net/v3/${r}/messages`,a=e.from??process.env.EMAIL_FROM??"noreply@kitabuyetu.com",s=process.env.EMAIL_FROM_NAME??"Kitabu Yetu",i=Array.isArray(e.to)?e.to:[e.to],l=null;try{let{rows:t}=await (0,n.xh)(t=>t.query(`INSERT INTO email_logs
             (group_id, user_id, template_key, category, "to", "from", subject,
              provider, status, reference_id, reference_type)
           VALUES ($1,$2,$3,$4,$5,$6,$7,'mailgun','queued',$8,$9) RETURNING id`,[e.groupId??null,e.userId??null,e.templateKey??null,e.category??"transactional",i[0],a,e.subject,e.referenceId??null,e.referenceType??null]));l=t[0]?.id??null}catch{}try{let r=new FormData;if(r.append("from",`${s} <${a}>`),r.append("to",i.join(",")),r.append("subject",e.subject??""),e.html&&r.append("html",e.html),e.text&&r.append("text",e.text),e.replyTo&&r.append("h:Reply-To",e.replyTo),e.cc){let t=Array.isArray(e.cc)?e.cc:[e.cc];r.append("cc",t.join(","))}if(e.attachments?.length)for(let t of e.attachments){let e=Buffer.isBuffer(t.content)?t.content:Buffer.from(t.content,"base64");r.append("attachment",new Blob([new Uint8Array(e)],{type:t.contentType??"application/octet-stream"}),t.filename)}let d=Buffer.from(`api:${t}`).toString("base64"),p=await fetch(o,{method:"POST",headers:{Authorization:`Basic ${d}`},body:r});if(!p.ok){let e=await p.text();throw Error(`Mailgun ${p.status}: ${e}`)}let c=(await p.json()).id??void 0;return l&&await (0,n.xh)(e=>e.query("UPDATE email_logs SET status='sent', provider_message_id=$1, sent_at=NOW() WHERE id=$2",[c??null,l])).catch(()=>{}),{success:!0,messageId:c,provider:this.name}}catch(t){let e=t instanceof Error?t.message:String(t);return l&&await (0,n.xh)(t=>t.query("UPDATE email_logs SET status='failed', error_message=$1 WHERE id=$2",[e,l])).catch(()=>{}),{success:!1,error:e,provider:this.name}}}constructor(){this.name="mailgun"}}let g=null;async function m(e){let t=e.from??process.env.EMAIL_FROM??"noreply@kitabuyetu.com",r=Array.isArray(e.to)?e.to[0]:e.to;await (0,n.xh)(o=>o.query(`INSERT INTO email_logs
         (group_id, user_id, template_key, category, "to", "from", subject,
          provider, status, reference_id, reference_type)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'dry_run',$9,$10)`,[e.groupId??null,e.userId??null,e.templateKey??null,e.category??"transactional",r,t,e.subject,process.env.EMAIL_PROVIDER??"resend",e.referenceId??null,e.referenceType??null])).catch(()=>{})}async function y(e){if("true"===process.env.EMAIL_DRY_RUN)return await m(e),{success:!0,provider:"dry_run",dryRun:!0};let t=function(){if(g)return g;switch(process.env.EMAIL_PROVIDER??"resend"){case"sendgrid":g=new p;break;case"ses":g=new c;break;case"mailgun":g=new u;break;case"smtp":g=new d;break;default:g=new s}return g}(),r=await t.send(e);return r.success?r:"smtp"!==t.name&&process.env.SMTP_HOST?(console.warn(`[email] ${t.name} failed, falling back to SMTP:`,r.error),new d().send(e)):r}},15446:(e,t,r)=>{r.d(t,{K:()=>o});let o={welcome:{subject:"Welcome to Kitabu Yetu, {{name}}!",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Welcome, {{name}}!</h2>
      <p style="margin:0 0 12px;color:#374151;">Your account has been created for <strong>{{groupName}}</strong>.</p>
      <p style="margin:0 0 20px;color:#374151;">You can now log in and start managing your group's finances.</p>
      <a href="{{loginUrl}}" style="display:inline-block;background:#16a34a;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:600;">Log In Now</a>
      <p style="margin:20px 0 0;font-size:13px;color:#6b7280;">Your temporary password is: <strong>{{tempPassword}}</strong><br>Please change it after first login.</p>
    `},otp:{subject:"Your Kitabu Yetu verification code: {{otp}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Verification Code</h2>
      <p style="margin:0 0 20px;color:#374151;">Use the code below to verify your identity. It expires in <strong>{{expiresIn}}</strong>.</p>
      <div style="background:#f3f4f6;border-radius:8px;padding:24px;text-align:center;margin:0 0 20px;">
        <span style="font-size:36px;font-weight:700;letter-spacing:8px;color:#111827;">{{otp}}</span>
      </div>
      <p style="margin:0;font-size:13px;color:#6b7280;">If you did not request this code, please ignore this email.</p>
    `},password_reset:{subject:"Reset your Kitabu Yetu password",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Password Reset Request</h2>
      <p style="margin:0 0 20px;color:#374151;">Click the button below to reset your password. This link expires in <strong>{{expiresIn}}</strong>.</p>
      <a href="{{resetUrl}}" style="display:inline-block;background:#16a34a;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:600;">Reset Password</a>
      <p style="margin:20px 0 0;font-size:13px;color:#6b7280;">If you did not request a password reset, please ignore this email.</p>
    `},account_update:{subject:"Your Kitabu Yetu account has been updated",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Account Updated</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{name}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Your account details have been updated: <strong>{{changeDescription}}</strong>.</p>
      <p style="margin:0 0 20px;color:#374151;">If you did not make this change, please contact your group administrator immediately.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">Change time: {{changedAt}}</p>
    `},contribution_received:{subject:"Contribution received — KES {{amount}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Contribution Confirmed</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">We have received your contribution of <strong>KES {{amount}}</strong> for <strong>{{periodLabel}}</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Reference</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">{{reference}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Date</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">{{date}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Payment Method</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">{{paymentMethod}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">Your total contributions to date: <strong>KES {{totalContributions}}</strong></p>
    `},contribution_reminder:{subject:"Reminder: {{periodLabel}} contribution due {{dueDate}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Contribution Reminder</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">This is a friendly reminder that your <strong>{{periodLabel}}</strong> contribution of <strong>KES {{amount}}</strong> is due on <strong>{{dueDate}}</strong>.</p>
      <p style="margin:0 0 20px;color:#374151;">Please use M-Pesa Paybill <strong>{{shortcode}}</strong>, Account Number: <strong>{{accountNumber}}</strong>.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">For any queries, contact your group secretary.</p>
    `},loan_approved:{subject:"Your loan application has been approved",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Loan Approved</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Your loan application has been <strong style="color:#16a34a;">approved</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Principal</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">KES {{principal}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Interest Rate</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">{{interestRate}}% per month</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Term</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">{{termMonths}} months</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Monthly Repayment</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;">KES {{monthlyRepayment}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">Disbursement will be processed shortly. You will receive an M-Pesa notification.</p>
    `},loan_rejected:{subject:"Your loan application was not approved",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Loan Application Update</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">We regret to inform you that your loan application for <strong>KES {{principal}}</strong> has not been approved at this time.</p>
      <p style="margin:0 0 20px;color:#374151;"><strong>Reason:</strong> {{reason}}</p>
      <p style="margin:0 0 20px;color:#374151;">You may re-apply after <strong>{{reapplyDate}}</strong> or contact your group administrator for further guidance.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">We appreciate your continued membership and commitment to the group.</p>
    `},loan_disbursed:{subject:"Loan of KES {{amount}} disbursed to your M-Pesa",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Loan Disbursed</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">KES <strong>{{amount}}</strong> has been sent to your M-Pesa number <strong>{{phone}}</strong>.</p>
      <p style="margin:0 0 20px;color:#374151;">M-Pesa Transaction ID: <strong>{{mpesaRef}}</strong></p>
      <p style="margin:0 0 20px;color:#374151;">Your first repayment of <strong>KES {{monthlyRepayment}}</strong> is due on <strong>{{firstDueDate}}</strong>.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">Please ensure timely repayments to maintain your good standing.</p>
    `},loan_overdue:{subject:"URGENT: Loan repayment {{daysOverdue}} days overdue",body:`
      <h2 style="margin:0 0 16px;color:#dc2626;">Overdue Loan Repayment</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Your loan repayment of <strong>KES {{amountDue}}</strong> is <strong style="color:#dc2626;">{{daysOverdue}} days overdue</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Outstanding Balance</td><td style="padding:8px;border:1px solid #e5e7eb;color:#dc2626;font-weight:600;">KES {{balance}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Penalty Accrued</td><td style="padding:8px;border:1px solid #e5e7eb;color:#dc2626;">KES {{penalty}}</td></tr>
      </table>
      <p style="margin:0 0 20px;color:#374151;">Please make payment immediately via M-Pesa Paybill <strong>{{shortcode}}</strong>, Account: <strong>{{accountNumber}}</strong>.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">Failure to pay may affect your loan eligibility. Contact your secretary for payment arrangements.</p>
    `},loan_repayment_received:{subject:"Loan repayment of KES {{amount}} received",body:`
      <h2 style="margin:0 0 16px;color:#16a34a;">Repayment Received</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">We have received your loan repayment of <strong>KES {{amount}}</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Payment Date</td><td style="padding:8px;border:1px solid #e5e7eb;">{{paymentDate}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Remaining Balance</td><td style="padding:8px;border:1px solid #e5e7eb;font-weight:600;">KES {{remainingBalance}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Next Due Date</td><td style="padding:8px;border:1px solid #e5e7eb;">{{nextDueDate}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">Thank you for your prompt payment.</p>
    `},invoice:{subject:"Invoice {{invoiceNumber}} — KES {{amountDue}} due {{dueDate}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Invoice {{invoiceNumber}}</h2>
      <p style="margin:0 0 20px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Invoice Date</td><td style="padding:8px;border:1px solid #e5e7eb;">{{invoiceDate}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Due Date</td><td style="padding:8px;border:1px solid #e5e7eb;color:#dc2626;font-weight:600;">{{dueDate}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Amount Due</td><td style="padding:8px;border:1px solid #e5e7eb;font-weight:700;font-size:18px;color:#111827;">KES {{amountDue}}</td></tr>
      </table>
      <p style="margin:0 0 16px;color:#374151;font-style:italic;">{{notes}}</p>
      <p style="margin:0 0 8px;color:#374151;font-weight:600;">Payment Instructions:</p>
      <p style="margin:0 0 20px;color:#374151;">M-Pesa Paybill <strong>{{shortcode}}</strong>, Account: <strong>{{invoiceNumber}}</strong></p>
      <p style="margin:0;font-size:13px;color:#6b7280;">A PDF copy of this invoice is attached.</p>
    `},invoice_overdue_1:{subject:"Invoice {{invoiceNumber}} overdue — please pay KES {{amountDue}}",body:`
      <h2 style="margin:0 0 16px;color:#d97706;">First Overdue Notice — Invoice {{invoiceNumber}}</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Invoice {{invoiceNumber}} for <strong>KES {{amountDue}}</strong> was due on <strong>{{dueDate}}</strong> and remains unpaid.</p>
      <p style="margin:0 0 20px;color:#374151;">Please make payment at your earliest convenience via M-Pesa Paybill <strong>{{shortcode}}</strong>, Account: <strong>{{invoiceNumber}}</strong>.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">If you have already made payment, please ignore this notice.</p>
    `},invoice_overdue_2:{subject:"SECOND NOTICE: Invoice {{invoiceNumber}} — {{daysOverdue}} days past due",body:`
      <h2 style="margin:0 0 16px;color:#dc2626;">Second Overdue Notice — Invoice {{invoiceNumber}}</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Invoice {{invoiceNumber}} for <strong>KES {{amountDue}}</strong> is now <strong style="color:#dc2626;">{{daysOverdue}} days overdue</strong>.</p>
      <p style="margin:0 0 20px;color:#374151;">Immediate payment is required. Late fees may apply. Please pay via M-Pesa Paybill <strong>{{shortcode}}</strong>, Account: <strong>{{invoiceNumber}}</strong>.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">Contact <strong>{{adminEmail}}</strong> if you need to discuss a payment arrangement.</p>
    `},invoice_overdue_3:{subject:"FINAL NOTICE: Invoice {{invoiceNumber}} — immediate action required",body:`
      <h2 style="margin:0 0 16px;color:#dc2626;">FINAL NOTICE — Invoice {{invoiceNumber}}</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">This is your <strong>final notice</strong>. Invoice {{invoiceNumber}} for <strong>KES {{amountDue}}</strong> is <strong style="color:#dc2626;">{{daysOverdue}} days past due</strong>.</p>
      <p style="margin:0 0 20px;color:#374151;">Failure to pay within 7 days may result in service suspension. Pay immediately via M-Pesa Paybill <strong>{{shortcode}}</strong>, Account: <strong>{{invoiceNumber}}</strong>.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">To resolve this urgently, contact <strong>{{adminEmail}}</strong> or call <strong>{{adminPhone}}</strong>.</p>
    `},payment_receipt:{subject:"Payment received — KES {{amountPaid}} (Receipt {{receiptNumber}})",body:`
      <h2 style="margin:0 0 16px;color:#16a34a;">Payment Received</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Thank you! We have received your payment of <strong>KES {{amountPaid}}</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Receipt Number</td><td style="padding:8px;border:1px solid #e5e7eb;color:#111827;font-weight:700;">{{receiptNumber}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Invoice</td><td style="padding:8px;border:1px solid #e5e7eb;">{{invoiceNumber}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Payment Date</td><td style="padding:8px;border:1px solid #e5e7eb;">{{paymentDate}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Method</td><td style="padding:8px;border:1px solid #e5e7eb;">{{paymentMethod}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Amount Paid</td><td style="padding:8px;border:1px solid #e5e7eb;color:#16a34a;font-weight:700;">KES {{amountPaid}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">A PDF receipt is attached for your records.</p>
    `},meeting_invite:{subject:"{{groupName}}: Meeting on {{meetingDate}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Meeting Invitation</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">You are invited to the <strong>{{meetingType}}</strong> meeting for <strong>{{groupName}}</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Date</td><td style="padding:8px;border:1px solid #e5e7eb;font-weight:600;">{{meetingDate}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Time</td><td style="padding:8px;border:1px solid #e5e7eb;">{{meetingTime}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Venue</td><td style="padding:8px;border:1px solid #e5e7eb;">{{venue}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Agenda</td><td style="padding:8px;border:1px solid #e5e7eb;">{{agenda}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">Please confirm your attendance by replying to this email. — <strong>{{organizerName}}</strong></p>
    `},meeting_reminder:{subject:"Reminder: {{groupName}} meeting tomorrow at {{meetingTime}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Meeting Reminder</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">This is a reminder for tomorrow's <strong>{{meetingType}}</strong> meeting.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Date &amp; Time</td><td style="padding:8px;border:1px solid #e5e7eb;font-weight:600;">{{meetingDate}} at {{meetingTime}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Venue</td><td style="padding:8px;border:1px solid #e5e7eb;">{{venue}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">We look forward to seeing you there.</p>
    `},monthly_statement:{subject:"{{groupName}}: Your {{month}} Statement",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Monthly Statement — {{month}}</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Please find your statement for <strong>{{month}}</strong> attached.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Total Contributions</td><td style="padding:8px;border:1px solid #e5e7eb;color:#16a34a;font-weight:600;">KES {{totalContributions}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Loan Balance</td><td style="padding:8px;border:1px solid #e5e7eb;">KES {{loanBalance}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Group Fund Share</td><td style="padding:8px;border:1px solid #e5e7eb;font-weight:600;">KES {{fundShare}}</td></tr>
      </table>
      <p style="margin:0;font-size:13px;color:#6b7280;">The full statement is attached as a PDF.</p>
    `},financial_report:{subject:"{{groupName}}: {{reportType}} — {{period}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">{{reportType}}</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">The <strong>{{reportType}}</strong> for <strong>{{period}}</strong> is attached.</p>
      <p style="margin:0 0 20px;color:#374151;background:#f0fdf4;padding:12px;border-radius:4px;border-left:4px solid #16a34a;">
        <strong>Confidential:</strong> This report contains sensitive financial data. Please keep it secure and do not forward to unauthorized recipients.
      </p>
      <p style="margin:0;font-size:13px;color:#6b7280;">Generated: {{generatedAt}} — {{groupName}}</p>
    `},weekly_summary:{subject:"{{groupName}}: Weekly Summary — {{weekLabel}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Weekly Summary</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{recipientName}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Here's a quick snapshot of <strong>{{groupName}}</strong> activity for the week of <strong>{{weekLabel}}</strong>.</p>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Contributions Collected</td><td style="padding:8px;border:1px solid #e5e7eb;color:#16a34a;font-weight:600;">KES {{weekContributions}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Loans Disbursed</td><td style="padding:8px;border:1px solid #e5e7eb;">KES {{weekLoans}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Repayments Received</td><td style="padding:8px;border:1px solid #e5e7eb;">KES {{weekRepayments}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">New Members</td><td style="padding:8px;border:1px solid #e5e7eb;">{{newMembers}}</td></tr>
      </table>
    `},birthday:{subject:"Happy Birthday {{memberName}}! \uD83C\uDF89 From {{groupName}}",body:`
      <div style="text-align:center;margin:0 0 24px;">
        <div style="font-size:48px;">🎂</div>
        <h2 style="margin:8px 0 0;color:#111827;">Happy Birthday, {{memberName}}!</h2>
      </div>
      <p style="margin:0 0 20px;color:#374151;text-align:center;">Your <strong>{{groupName}}</strong> family wishes you a wonderful birthday and a prosperous year ahead.</p>
      <p style="margin:0 0 20px;color:#374151;text-align:center;">May this new year bring you joy, health, and financial prosperity.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;text-align:center;">With warm wishes from all of us at <strong>{{groupName}}</strong> 🎉</p>
    `},announcement:{subject:"{{groupName}}: {{subject}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">{{subject}}</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{memberName}}</strong>,</p>
      <div style="margin:0 0 20px;color:#374151;line-height:1.6;">{{body}}</div>
      <p style="margin:0;font-size:13px;color:#6b7280;">— <strong>{{senderName}}</strong>, {{groupName}}</p>
    `},newsletter_confirm:{subject:"Confirm your subscription to Kitabu Yetu updates",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Confirm Your Subscription</h2>
      <p style="margin:0 0 20px;color:#374151;">You recently subscribed to receive updates from Kitabu Yetu. Please confirm your email address by clicking the button below.</p>
      <a href="{{confirmUrl}}" style="display:inline-block;background:#16a34a;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:600;">Confirm Subscription</a>
      <p style="margin:20px 0 0;font-size:13px;color:#6b7280;">If you did not subscribe, please ignore this email. This link expires in 24 hours.</p>
    `},newsletter_welcome:{subject:"You're subscribed to Kitabu Yetu updates",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Welcome to Kitabu Yetu Updates!</h2>
      <p style="margin:0 0 20px;color:#374151;">Thank you for confirming your subscription. You will receive updates about new features, community finance tips, and product announcements.</p>
      <p style="margin:0;font-size:13px;color:#6b7280;">You can unsubscribe at any time by clicking the unsubscribe link in any future email.</p>
    `},contact_confirmation:{subject:"We received your message — Kitabu Yetu",body:`
      <h2 style="margin:0 0 16px;color:#111827;">Message Received</h2>
      <p style="margin:0 0 12px;color:#374151;">Dear <strong>{{name}}</strong>,</p>
      <p style="margin:0 0 20px;color:#374151;">Thank you for contacting us. We have received your message and will respond within <strong>2 business days</strong>.</p>
      <div style="background:#f3f4f6;border-radius:6px;padding:16px;margin:0 0 20px;">
        <p style="margin:0;font-size:13px;color:#374151;font-weight:600;">Your message:</p>
        <p style="margin:8px 0 0;font-size:13px;color:#374151;">{{message}}</p>
      </div>
      <p style="margin:0;font-size:13px;color:#6b7280;">Reference: <strong>{{reference}}</strong></p>
    `},contact_admin:{subject:"New contact form submission from {{name}}",body:`
      <h2 style="margin:0 0 16px;color:#111827;">New Contact Submission</h2>
      <table width="100%" style="border-collapse:collapse;margin:0 0 20px;">
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Name</td><td style="padding:8px;border:1px solid #e5e7eb;">{{name}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Email</td><td style="padding:8px;border:1px solid #e5e7eb;">{{email}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">Subject</td><td style="padding:8px;border:1px solid #e5e7eb;">{{contactSubject}}</td></tr>
        <tr><td style="padding:8px;border:1px solid #e5e7eb;background:#f9fafb;font-weight:600;color:#374151;">IP</td><td style="padding:8px;border:1px solid #e5e7eb;font-size:12px;color:#6b7280;">{{ip}}</td></tr>
      </table>
      <div style="background:#f3f4f6;border-radius:6px;padding:16px;">
        <p style="margin:0;font-weight:600;font-size:13px;color:#374151;">Message:</p>
        <p style="margin:8px 0 0;font-size:14px;color:#111827;line-height:1.6;">{{message}}</p>
      </div>
    `}}},95958:(e,t,r)=>{r.d(t,{SM:()=>l,Y:()=>i,w_:()=>s});var o=r(97395);function n(e,t){return e.replace(/\{\{(\w+)\}\}/g,(e,r)=>{let o=t[r];return null==o?"":String(o)})}async function a(e,t,r="en"){let{rows:n}=await (0,o.xh)(o=>o.query(`SELECT subject, body FROM email_templates
       WHERE template_key=$1
         AND (group_id=$2 OR group_id IS NULL)
         AND locale=$3
         AND is_active=true
       ORDER BY group_id NULLS LAST
       LIMIT 1`,[e,t,r]));if(n.length)return{subject:n[0].subject,body:n[0].body};if("en"!==r){let{rows:r}=await (0,o.xh)(r=>r.query(`SELECT subject, body FROM email_templates
         WHERE template_key=$1
           AND (group_id=$2 OR group_id IS NULL)
           AND locale='en'
           AND is_active=true
         ORDER BY group_id NULLS LAST
         LIMIT 1`,[e,t]));if(r.length)return{subject:r[0].subject,body:r[0].body}}return null}async function s(e){if(!e)return{};try{let{rows:t}=await (0,o.xh)(t=>t.query(`SELECT sender_name, logo_url, primary_color, footer_text
         FROM group_email_branding WHERE group_id=$1`,[e]));if(!t.length)return{};return{senderName:t[0].sender_name,logoUrl:t[0].logo_url,primaryColor:t[0].primary_color,footerText:t[0].footer_text}}catch{return{}}}function i(e,t){let r=t.primaryColor??"#16a34a",o=t.footerText??"Kitabu Yetu — Community Finance Management",n=t.logoUrl?`<img src="${t.logoUrl}" alt="Logo" style="height:40px;margin-bottom:16px;">`:`<div style="font-size:20px;font-weight:700;color:${r};margin-bottom:16px;">Kitabu Yetu</div>`;return`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Email</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:24px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;max-width:600px;width:100%;">
        <tr>
          <td style="background:${r};padding:24px 32px;text-align:center;">
            ${n}
          </td>
        </tr>
        <tr>
          <td style="padding:32px;">
            ${e}
          </td>
        </tr>
        <tr>
          <td style="background:#f9fafb;padding:20px 32px;text-align:center;border-top:1px solid #e5e7eb;">
            <p style="margin:0;font-size:12px;color:#6b7280;">${o}</p>
            <p style="margin:8px 0 0;font-size:11px;color:#9ca3af;">
              If you did not expect this email, you can safely ignore it.
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`}async function l(e,t,r,o="en",l){let d=await s(r),p=await a(e,r,o);if(p)return{subject:n(p.subject,t),html:i(n(p.body,t),d)};if(l){let e=i(n(l,t),d);return{subject:t.subject?String(t.subject):"Kitabu Yetu",html:e}}throw Error(`Email template '${e}' not found and no fallback provided.`)}},3357:(e,t,r)=>{r.d(t,{GT:()=>n,Rp:()=>d,SP:()=>i,Z$:()=>p,jF:()=>l});var o=r(47942);let n={MPESA_RECONCILE:"mpesa:reconcile",MPESA_STATUS_CHECK:"mpesa:status_check",FAILED_PAYMENT_RETRY:"failed_payment:retry",BILL_MGR_SEND:"bill_mgr:send",SMS_SEND:"sms:send",SMS_BULK:"sms:bulk",SMS_RETRY:"sms:retry",SMS_BIRTHDAY:"sms:birthday",SMS_SCHEDULED:"sms:scheduled",EMAIL_SEND:"email:send",EMAIL_HIGH:"email:high",EMAIL_LOW:"email:low",EMAIL_BILLING:"email:billing",EMAIL_SCHEDULED:"email:scheduled"},a=e=>`queue:${e}`,s=e=>`dlq:${e}`;async function i(e,t,r={}){let n=`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,s=Date.now(),i={id:n,queue:e,data:t,attempts:0,maxAttempts:r.maxAttempts??3,enqueuedAt:s,processAt:s+(r.delayMs??0)};return await o.T8.zadd(a(e),i.processAt,JSON.stringify(i)),n}async function l(e,t=10){let r=await o.T8.zrangebyscore(a(e),"-inf",Date.now(),"LIMIT",0,t);if(!r.length)return[];let n=o.T8.pipeline();return r.forEach(t=>n.zrem(a(e),t)),await n.exec(),r.map(e=>JSON.parse(e))}async function d(e){let t={...e,attempts:e.attempts+1,processAt:Date.now()+1e3*2**e.attempts};await o.T8.zadd(a(e.queue),t.processAt,JSON.stringify(t))}async function p(e,t){let r=JSON.stringify({...e,error:t,failedAt:Date.now()});await o.T8.lpush(s(e.queue),r),await o.T8.ltrim(s(e.queue),0,499)}},47942:(e,t,r)=>{r.d(t,{Fh:()=>u,T8:()=>i,Ut:()=>c,YV:()=>p,_b:()=>f,dn:()=>b,ji:()=>g,kL:()=>y,nM:()=>m,yK:()=>d});var o=r(41495),n=r.n(o);if(!process.env.REDIS_URL)throw Error("REDIS_URL environment variable is not set");let a=process.env.REDIS_PREFIX??"ky:",s=globalThis;s._kyRedis||(s._kyRedis=new(n())(process.env.REDIS_URL,{keyPrefix:a,maxRetriesPerRequest:3,enableOfflineQueue:!1,lazyConnect:!1}),s._kyRedis.on("error",e=>{console.error("[redis] Connection error:",e.message)}));let i=s._kyRedis,l={refreshToken:e=>`rt:${e}`,loginAttempts:e=>`login_attempts:${e}`,accountLock:e=>`account_lock:${e}`,mpesaStatus:e=>`mpesa:${e}`};async function d(e,t,r){await i.set(l.refreshToken(e),t,"EX",r)}async function p(e){return i.get(l.refreshToken(e))}async function c(e){await i.del(l.refreshToken(e))}async function u(e){let t=l.loginAttempts(e),r=await i.incr(t);return 1===r&&await i.expire(t,3600),r}async function g(e){await i.del(l.loginAttempts(e))}async function m(e,t){await i.set(l.accountLock(e),"1","EX",60*t)}async function y(e){return null!==await i.get(l.accountLock(e))}async function b(e,t,r=300){await i.set(l.mpesaStatus(e),t,"EX",r)}async function f(e){return await i.get(l.mpesaStatus(e))}}};