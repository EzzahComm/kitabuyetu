"use strict";exports.id=6594,exports.ids=[6594],exports.modules={97395:(e,t,a)=>{a.d(t,{ZG:()=>u,pool:()=>n,withDb:()=>o,xh:()=>c});var i=a(35900);if(!process.env.DATABASE_URL)throw Error("DATABASE_URL environment variable is not set");let s=globalThis;s._kyPool||(s._kyPool=new i.Pool({connectionString:process.env.DATABASE_URL,max:3,idleTimeoutMillis:1e4,connectionTimeoutMillis:8e3,ssl:(process.env.DATABASE_URL?.includes("supabase.com")||process.env.DATABASE_URL?.includes("supabase.co"),{rejectUnauthorized:!1})}),s._kyPool.on("error",e=>{console.error("[pg pool] Unexpected error on idle client:",e)}));let n=s._kyPool;async function r(e,t){await e.query("SELECT set_config($1, $2, TRUE)",["app.current_user_id",t.userId]),await e.query("SELECT set_config($1, $2, TRUE)",["app.current_group_id",t.groupId]),await e.query("SELECT set_config($1, $2, TRUE)",["app.current_role",t.role]),t.ngoId&&await e.query("SELECT set_config($1, $2, TRUE)",["app.current_ngo_id",t.ngoId])}async function o(e,t){let a=await n.connect();try{await a.query("BEGIN"),await r(a,e);let i=await t(a);return await a.query("COMMIT"),i}catch(e){throw await a.query("ROLLBACK"),e}finally{a.release()}}async function u(e,t){return o(e,t)}async function c(e){let t=await n.connect();try{await t.query("BEGIN");let a=await e(t);return await t.query("COMMIT"),a}catch(e){throw await t.query("ROLLBACK"),e}finally{t.release()}}},26594:(e,t,a)=>{a.d(t,{$J:()=>l,II:()=>u,RO:()=>m,Xt:()=>_,gB:()=>d,gu:()=>p,nc:()=>E,rK:()=>c,wY:()=>$});var i=a(97395),s=a(47942),n=a(94538),r=a(28909),o=a(69248);async function u(e){let t=(0,n.UK)(e.phone),a=(0,r.nR)(e.amount).toFixed(2),u=await (0,o.yt)({phone:t,amount:e.amount,accountReference:e.accountReference,description:e.description});return await (0,i.xh)(async i=>{let{rows:s}=await i.query(`INSERT INTO mpesa_transactions
         (group_id, transaction_type, direction, phone_number, amount,
          status, reference, description, raw_request)
       VALUES ($1,'stk_push','inbound',$2,$3,'pending',$4,$5,$6)
       RETURNING id`,[e.groupId,t,a,e.accountReference,e.description,JSON.stringify({checkoutRequestId:u.checkoutRequestId})]),n=s[0]?.id??null;await i.query(`INSERT INTO mpesa_stk_requests
         (group_id, mpesa_transaction_id, checkout_request_id, merchant_request_id,
          phone, amount, account_reference, description, purpose,
          status, invoice_id, initiated_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'pending',$10,$11)
       ON CONFLICT (checkout_request_id) DO NOTHING`,[e.groupId,n,u.checkoutRequestId,u.merchantRequestId,t,a,e.accountReference.slice(0,12),e.description.slice(0,20),e.purpose??null,e.invoiceId??null,e.initiatedBy??null]),await i.query(`INSERT INTO payments
         (group_id, invoice_id, amount, payment_method, status,
          mpesa_checkout_request_id, mpesa_merchant_request_id, mpesa_phone)
       VALUES ($1,$2,$3,'mpesa','pending',$4,$5,$6)
       ON CONFLICT (mpesa_checkout_request_id) DO NOTHING`,[e.groupId,e.invoiceId??null,a,u.checkoutRequestId,u.merchantRequestId,t])}),await (0,s.dn)(u.checkoutRequestId,"pending"),{checkoutRequestId:u.checkoutRequestId,merchantRequestId:u.merchantRequestId,responseCode:u.responseCode,responseDescription:u.responseDescription}}async function c(e,t){(0,o.nx)(t);let a=e.Body.stkCallback;if(0!==a.ResultCode)return await (0,i.xh)(async t=>{await t.query(`UPDATE payments SET status='failed'
         WHERE mpesa_checkout_request_id=$1 AND status='pending'`,[a.CheckoutRequestID]),await t.query(`UPDATE mpesa_stk_requests SET status='failed', completed_at=NOW()
         WHERE checkout_request_id=$1`,[a.CheckoutRequestID]),await t.query(`UPDATE mpesa_transactions t
         SET status='failed', failure_reason=$2, raw_response=$3, completed_at=NOW()
         FROM mpesa_stk_requests s
         WHERE s.mpesa_transaction_id=t.id AND s.checkout_request_id=$1`,[a.CheckoutRequestID,a.ResultDesc,JSON.stringify(e)]),await t.query(`INSERT INTO failed_payment_logs
           (transaction_type, reference_id, failure_reason, raw_data)
         VALUES ('stk_push',$1,$2,$3)`,[a.CheckoutRequestID,a.ResultDesc,JSON.stringify(e)])}),await (0,s.dn)(a.CheckoutRequestID,"failed"),{success:!1,mpesaReceiptNumber:null,amount:null,paymentId:null};let r=a.CallbackMetadata.Item,u=e=>r.find(t=>t.Name===e)?.Value,c=u("MpesaReceiptNumber"),d=u("Amount"),_=(0,n.UK)(String(u("PhoneNumber")??"")),p=await (0,i.xh)(async e=>{let{rows:t}=await e.query(`SELECT id, status FROM payments
       WHERE mpesa_receipt_number=$1 OR mpesa_checkout_request_id=$2
       LIMIT 1`,[c,a.CheckoutRequestID]);return t[0]??null});if(p?.status==="completed")return await (0,s.dn)(a.CheckoutRequestID,"completed"),{success:!0,mpesaReceiptNumber:c,amount:d,paymentId:p.id};let l=await (0,i.xh)(async t=>{let{rows:i}=await t.query(`UPDATE payments
       SET status='completed', mpesa_receipt_number=$1,
           mpesa_raw_callback=$2, payment_date=NOW()
       WHERE mpesa_checkout_request_id=$3 AND status='pending'
       RETURNING id, invoice_id`,[c,JSON.stringify(e),a.CheckoutRequestID]);return i[0]?(i[0].invoice_id&&await t.query(`UPDATE invoices
         SET paid_amount=paid_amount+$1,
             status=CASE WHEN paid_amount+$1>=total_amount THEN 'completed'::payment_status
                         ELSE status END
         WHERE id=$2`,[d.toFixed(2),i[0].invoice_id]),await t.query(`UPDATE mpesa_stk_requests
       SET status='completed', raw_callback=$1, completed_at=NOW()
       WHERE checkout_request_id=$2`,[JSON.stringify(e),a.CheckoutRequestID]),await t.query(`UPDATE mpesa_transactions t
       SET status='completed', mpesa_receipt_number=$1,
           raw_response=$2, completed_at=NOW(), phone_number=$3
       FROM mpesa_stk_requests s
       WHERE s.mpesa_transaction_id=t.id AND s.checkout_request_id=$4`,[c,JSON.stringify(e),_,a.CheckoutRequestID]),i[0].id):null});return await (0,s.dn)(a.CheckoutRequestID,"completed"),{success:!0,mpesaReceiptNumber:c,amount:d,paymentId:l}}async function d(e,t){(0,o.nx)(t),await (0,i.xh)(async t=>{let{rows:a}=await t.query("SELECT id FROM payments WHERE mpesa_receipt_number=$1",[e.TransID]);if(a[0])return;let{rows:i}=await t.query("SELECT id FROM groups WHERE UPPER(name)=UPPER($1) AND is_active=true LIMIT 1",[e.BillRefNumber]);if(!i[0])return;let s=(0,n.UK)(e.MSISDN),r=parseFloat(e.TransAmount).toFixed(2);await t.query(`INSERT INTO mpesa_transactions
         (group_id, transaction_type, direction, mpesa_receipt_number,
          phone_number, amount, status, reference, raw_response, completed_at)
       VALUES ($1,'c2b','inbound',$2,$3,$4,'completed',$5,$6,NOW())
       ON CONFLICT (mpesa_receipt_number) DO NOTHING`,[i[0].id,e.TransID,s,r,e.BillRefNumber,JSON.stringify(e)]),await t.query(`INSERT INTO payments
         (group_id, amount, payment_method, status, mpesa_receipt_number,
          mpesa_phone, mpesa_raw_callback, payment_date)
       VALUES ($1,$2,'mpesa','completed',$3,$4,$5,NOW())
       ON CONFLICT (mpesa_receipt_number) DO NOTHING`,[i[0].id,r,e.TransID,s,JSON.stringify(e)])})}async function _(e){let t=(0,n.UK)(e.phone),a=(0,r.nR)(e.amount).toFixed(2),s=await (0,o.Xt)({phone:t,amount:e.amount,commandId:e.commandId,remarks:e.occasion});return await (0,i.xh)(async i=>{let{rows:n}=await i.query(`INSERT INTO mpesa_transactions
         (group_id, transaction_type, direction, phone_number, amount,
          status, description, conversation_id, originator_conversation_id)
       VALUES ($1,'b2c','outbound',$2,$3,'initiated',$4,$5,$6)
       RETURNING id`,[e.groupId,t,a,e.occasion,s.conversationId,s.originatorConversationId]);await i.query(`INSERT INTO mpesa_b2c_transactions
         (group_id, mpesa_transaction_id, conversation_id,
          originator_conversation_id, phone, amount, command_id,
          occasion, remarks, status, loan_id, disbursed_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,'initiated',$9,$10)`,[e.groupId,n[0]?.id??null,s.conversationId,s.originatorConversationId,t,a,e.commandId,e.occasion,e.loanId??null,e.disbursedBy??null])}),{conversationId:s.conversationId,originatorConversationId:s.originatorConversationId,responseDescription:s.responseDescription}}async function p(e,t){(0,o.nx)(t);let a=e.Result;await (0,i.xh)(async t=>{let i;if(0!==a.ResultCode){await t.query(`UPDATE mpesa_b2c_transactions
         SET status='failed', raw_result=$1, result_received_at=NOW()
         WHERE originator_conversation_id=$2`,[JSON.stringify(e),a.OriginatorConversationID]),await t.query(`UPDATE mpesa_transactions
         SET status='failed', failure_reason=$1, raw_response=$2, completed_at=NOW()
         WHERE originator_conversation_id=$3`,[a.ResultDesc,JSON.stringify(e),a.OriginatorConversationID]),await t.query(`INSERT INTO failed_payment_logs
           (transaction_type, reference_id, failure_reason, failure_code, raw_data)
         VALUES ('b2c',$1,$2,$3,$4)`,[a.OriginatorConversationID,a.ResultDesc,String(a.ResultCode),JSON.stringify(e)]);return}let s=(i="TransactionReceipt",a.ResultParameters?.ResultParameter.find(e=>e.Key===i)?.Value);await t.query(`UPDATE mpesa_b2c_transactions
       SET status='completed', mpesa_receipt_number=$1,
           raw_result=$2, result_received_at=NOW()
       WHERE originator_conversation_id=$3`,[s??null,JSON.stringify(e),a.OriginatorConversationID]),await t.query(`UPDATE mpesa_transactions
       SET status='completed', mpesa_receipt_number=$1,
           raw_response=$2, completed_at=NOW()
       WHERE originator_conversation_id=$3`,[s??null,JSON.stringify(e),a.OriginatorConversationID])})}async function l(e,t){let a;(0,o.nx)(t);let s=e.Result;if(!s)return;let n=s.OriginatorConversationID??"",r=0===s.ResultCode,u=(a="TransactionReceipt",s.ResultParameters?.ResultParameter?.find(e=>e.Key===a)?.Value);await (0,i.xh)(async t=>{await t.query(`UPDATE mpesa_reversals
       SET status=$1, reversal_receipt=$2, raw_result=$3, result_received_at=NOW()
       WHERE originator_conversation_id=$4`,[r?"completed":"failed",u??null,JSON.stringify(e),n]),r&&u&&await t.query("UPDATE payments SET status='reversed' WHERE mpesa_receipt_number=$1",[u]),r||await t.query(`INSERT INTO failed_payment_logs
           (transaction_type, reference_id, failure_reason, failure_code, raw_data)
         VALUES ('reversal',$1,$2,$3,$4)`,[n,s.ResultDesc??"",String(s.ResultCode??""),JSON.stringify(e)])})}async function m(e,t){let a;(0,o.nx)(t);let s=e.Result;if(!s)return;let n=s.OriginatorConversationID??"",r=0===s.ResultCode,u=(a="TransactionReceipt",s.ResultParameters?.ResultParameter?.find(e=>e.Key===a)?.Value);await (0,i.xh)(async t=>{await t.query(`UPDATE mpesa_b2b_transactions
       SET status=$1, mpesa_receipt_number=$2, raw_result=$3, result_received_at=NOW()
       WHERE originator_conversation_id=$4`,[r?"completed":"failed",u??null,JSON.stringify(e),n]),await t.query(`UPDATE mpesa_transactions
       SET status=$1, mpesa_receipt_number=$2, raw_response=$3, completed_at=NOW()
       WHERE originator_conversation_id=$4`,[r?"completed":"failed",u??null,JSON.stringify(e),n])})}async function E(e,t){(0,o.nx)(t);let a=e.Result;a&&await (0,i.xh)(async t=>{await t.query(`UPDATE mpesa_transactions
       SET status=$1, raw_response=$2, completed_at=NOW()
       WHERE originator_conversation_id=$3 OR conversation_id=$4`,[0===a.ResultCode?"completed":"failed",JSON.stringify(e),a.OriginatorConversationID??"",a.ConversationID??""])})}async function $(e,t){let{rows:a}=await (0,i.xh)(a=>a.query(`INSERT INTO mpesa_reconciliations (group_id, initiated_by, status)
       VALUES ($1,$2,'running') RETURNING id`,[e,t])),n=a[0].id,r=0,u=0,c=0,d=[];try{let t=await (0,i.xh)(async t=>{let a=new Date(Date.now()-3e5),{rows:i}=e?await t.query(`SELECT id, checkout_request_id FROM mpesa_stk_requests
             WHERE status='pending' AND initiated_at<$1 AND group_id=$2 LIMIT 50`,[a,e]):await t.query(`SELECT id, checkout_request_id FROM mpesa_stk_requests
             WHERE status='pending' AND initiated_at<$1 LIMIT 50`,[a]);return i});for(let e of(r=t.length,t))try{let t=await (0,o.Rb)(e.checkout_request_id);if(u++,!("1032"!==t.resultCode))continue;let a="0"===t.resultCode?"completed":"failed";await (0,i.xh)(async t=>{await t.query("UPDATE mpesa_stk_requests SET status=$1, completed_at=NOW() WHERE id=$2",[a,e.id]),await t.query(`UPDATE payments SET status=$1
             WHERE mpesa_checkout_request_id=$2 AND status='pending'`,[a,e.checkout_request_id])}),await (0,s.dn)(e.checkout_request_id,a),c++,d.push({id:e.id,action:`resolved_${a}`,code:t.resultCode})}catch{d.push({id:e.id,action:"query_error"})}await (0,i.xh)(e=>e.query(`UPDATE mpesa_reconciliations
         SET status='completed', transactions_checked=$1, mismatches_found=$2,
             resolved_count=$3, details=$4, completed_at=NOW()
         WHERE id=$5`,[r,u,c,JSON.stringify(d),n]))}catch(e){throw await (0,i.xh)(t=>t.query("UPDATE mpesa_reconciliations SET status='failed', notes=$1 WHERE id=$2",[String(e),n])),e}return{reconciliationId:n,transactionsChecked:r,mismatchesFound:u,resolvedCount:c}}}};