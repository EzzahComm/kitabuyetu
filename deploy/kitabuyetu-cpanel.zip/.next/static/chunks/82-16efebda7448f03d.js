"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[82],{8030:function(t,e,i){i.d(e,{Z:function(){return u}});var s=i(2265);/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let n=t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),r=function(){for(var t=arguments.length,e=Array(t),i=0;i<t;i++)e[i]=arguments[i];return e.filter((t,e,i)=>!!t&&i.indexOf(t)===e).join(" ")};/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var o={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s.forwardRef)((t,e)=>{let{color:i="currentColor",size:n=24,strokeWidth:a=2,absoluteStrokeWidth:u,className:h="",children:c,iconNode:l,...d}=t;return(0,s.createElement)("svg",{ref:e,...o,width:n,height:n,stroke:i,strokeWidth:u?24*Number(a)/Number(n):a,className:r("lucide",h),...d},[...l.map(t=>{let[e,i]=t;return(0,s.createElement)(e,i)}),...Array.isArray(c)?c:[c]])}),u=(t,e)=>{let i=(0,s.forwardRef)((i,o)=>{let{className:u,...h}=i;return(0,s.createElement)(a,{ref:o,iconNode:e,className:r("lucide-".concat(n(t)),u),...h})});return i.displayName="".concat(t),i}},7427:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("BarChart2",[["line",{x1:"18",x2:"18",y1:"20",y2:"10",key:"1xfpm4"}],["line",{x1:"12",x2:"12",y1:"20",y2:"4",key:"be30l9"}],["line",{x1:"6",x2:"6",y1:"20",y2:"14",key:"1r4le6"}]])},518:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},7592:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},6938:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("CirclePause",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"10",x2:"10",y1:"15",y2:"9",key:"c1nkhi"}],["line",{x1:"14",x2:"14",y1:"15",y2:"9",key:"h65svq"}]])},472:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("CirclePlay",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polygon",{points:"10 8 16 12 10 16 10 8",key:"1cimsy"}]])},933:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},6044:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("LayoutTemplate",[["rect",{width:"18",height:"7",x:"3",y:"3",rx:"1",key:"f1a2em"}],["rect",{width:"9",height:"7",x:"3",y:"14",rx:"1",key:"jqznyg"}],["rect",{width:"5",height:"7",x:"16",y:"14",rx:"1",key:"q5h2i8"}]])},7390:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]])},2513:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},6706:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]])},994:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]])},883:function(t,e,i){i.d(e,{Z:function(){return s}});/**
 * @license lucide-react v0.411.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,i(8030).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},2812:function(t,e,i){i.d(e,{R:function(){return a},m:function(){return o}});var s=i(9948),n=i(3494),r=i(924),o=class extends n.F{#t;#e;#i;#s;constructor(t){super(),this.#t=t.client,this.mutationId=t.mutationId,this.#i=t.mutationCache,this.#e=[],this.state=t.state||a(),this.setOptions(t.options),this.scheduleGc()}setOptions(t){this.options=t,this.updateGcTime(this.options.gcTime)}get meta(){return this.options.meta}addObserver(t){this.#e.includes(t)||(this.#e.push(t),this.clearGcTimeout(),this.#i.notify({type:"observerAdded",mutation:this,observer:t}))}removeObserver(t){this.#e=this.#e.filter(e=>e!==t),this.scheduleGc(),this.#i.notify({type:"observerRemoved",mutation:this,observer:t})}optionalRemove(){this.#e.length||("pending"===this.state.status?this.scheduleGc():this.#i.remove(this))}continue(){return this.#s?.continue()??this.execute(this.state.variables)}async execute(t){let e=()=>{this.#n({type:"continue"})},i={client:this.#t,meta:this.options.meta,mutationKey:this.options.mutationKey};this.#s=(0,r.Mz)({fn:()=>this.options.mutationFn?this.options.mutationFn(t,i):Promise.reject(Error("No mutationFn found")),onFail:(t,e)=>{this.#n({type:"failed",failureCount:t,error:e})},onPause:()=>{this.#n({type:"pause"})},onContinue:e,retry:this.options.retry??0,retryDelay:this.options.retryDelay,networkMode:this.options.networkMode,canRun:()=>this.#i.canRun(this)});let s="pending"===this.state.status,n=!this.#s.canStart();try{if(s)e();else{this.#n({type:"pending",variables:t,isPaused:n}),this.#i.config.onMutate&&await this.#i.config.onMutate(t,this,i);let e=await this.options.onMutate?.(t,i);e!==this.state.context&&this.#n({type:"pending",context:e,variables:t,isPaused:n})}let r=await this.#s.start();return await this.#i.config.onSuccess?.(r,t,this.state.context,this,i),await this.options.onSuccess?.(r,t,this.state.context,i),await this.#i.config.onSettled?.(r,null,this.state.variables,this.state.context,this,i),await this.options.onSettled?.(r,null,t,this.state.context,i),this.#n({type:"success",data:r}),r}catch(e){try{await this.#i.config.onError?.(e,t,this.state.context,this,i)}catch(t){Promise.reject(t)}try{await this.options.onError?.(e,t,this.state.context,i)}catch(t){Promise.reject(t)}try{await this.#i.config.onSettled?.(void 0,e,this.state.variables,this.state.context,this,i)}catch(t){Promise.reject(t)}try{await this.options.onSettled?.(void 0,e,t,this.state.context,i)}catch(t){Promise.reject(t)}throw this.#n({type:"error",error:e}),e}finally{this.#i.runNext(this)}}#n(t){this.state=(e=>{switch(t.type){case"failed":return{...e,failureCount:t.failureCount,failureReason:t.error};case"pause":return{...e,isPaused:!0};case"continue":return{...e,isPaused:!1};case"pending":return{...e,context:t.context,data:void 0,failureCount:0,failureReason:null,error:null,isPaused:t.isPaused,status:"pending",variables:t.variables,submittedAt:Date.now()};case"success":return{...e,data:t.data,failureCount:0,failureReason:null,error:null,status:"success",isPaused:!1};case"error":return{...e,data:void 0,error:t.error,failureCount:e.failureCount+1,failureReason:t.error,isPaused:!1,status:"error"}}})(this.state),s.Vr.batch(()=>{this.#e.forEach(e=>{e.onMutationUpdate(t)}),this.#i.notify({mutation:this,type:"updated",action:t})})}};function a(){return{context:void 0,data:void 0,error:null,failureCount:0,failureReason:null,isPaused:!1,status:"idle",variables:void 0,submittedAt:0}}},5524:function(t,e,i){i.d(e,{D:function(){return c}});var s=i(2265),n=i(2812),r=i(9948),o=i(9010),a=i(6298),u=class extends o.l{#t;#r=void 0;#o;#a;constructor(t,e){super(),this.#t=t,this.setOptions(e),this.bindMethods(),this.#u()}bindMethods(){this.mutate=this.mutate.bind(this),this.reset=this.reset.bind(this)}setOptions(t){let e=this.options;this.options=this.#t.defaultMutationOptions(t),(0,a.VS)(this.options,e)||this.#t.getMutationCache().notify({type:"observerOptionsUpdated",mutation:this.#o,observer:this}),e?.mutationKey&&this.options.mutationKey&&(0,a.Ym)(e.mutationKey)!==(0,a.Ym)(this.options.mutationKey)?this.reset():this.#o?.state.status==="pending"&&this.#o.setOptions(this.options)}onUnsubscribe(){this.hasListeners()||this.#o?.removeObserver(this)}onMutationUpdate(t){this.#u(),this.#h(t)}getCurrentResult(){return this.#r}reset(){this.#o?.removeObserver(this),this.#o=void 0,this.#u(),this.#h()}mutate(t,e){return this.#a=e,this.#o?.removeObserver(this),this.#o=this.#t.getMutationCache().build(this.#t,this.options),this.#o.addObserver(this),this.#o.execute(t)}#u(){let t=this.#o?.state??(0,n.R)();this.#r={...t,isPending:"pending"===t.status,isSuccess:"success"===t.status,isError:"error"===t.status,isIdle:"idle"===t.status,mutate:this.mutate,reset:this.reset}}#h(t){r.Vr.batch(()=>{if(this.#a&&this.hasListeners()){let e=this.#r.variables,i=this.#r.context,s={client:this.#t,meta:this.options.meta,mutationKey:this.options.mutationKey};if(t?.type==="success"){try{this.#a.onSuccess?.(t.data,e,i,s)}catch(t){Promise.reject(t)}try{this.#a.onSettled?.(t.data,null,e,i,s)}catch(t){Promise.reject(t)}}else if(t?.type==="error"){try{this.#a.onError?.(t.error,e,i,s)}catch(t){Promise.reject(t)}try{this.#a.onSettled?.(void 0,t.error,e,i,s)}catch(t){Promise.reject(t)}}}this.listeners.forEach(t=>{t(this.#r)})})}},h=i(3191);function c(t,e){let i=(0,h.NL)(e),[n]=s.useState(()=>new u(i,t));s.useEffect(()=>{n.setOptions(t)},[n,t]);let o=s.useSyncExternalStore(s.useCallback(t=>n.subscribe(r.Vr.batchCalls(t)),[n]),()=>n.getCurrentResult(),()=>n.getCurrentResult()),c=s.useCallback((t,e)=>{n.mutate(t,e).catch(a.ZT)},[n]);if(o.error&&(0,a.L3)(n.options.throwOnError,[o.error]))throw o.error;return{...o,mutate:c,mutateAsync:o.mutate}}}}]);