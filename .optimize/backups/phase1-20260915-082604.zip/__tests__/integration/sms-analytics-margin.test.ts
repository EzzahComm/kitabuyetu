/**
 * SMS usage analytics (§8) and margin reporting (§15) against real Postgres.
 *
 * Phase 5 of docs/audits/SMS_MONETIZATION_AUDIT_2026-08.md. Two surfaces that
 * must not blur into each other:
 *
 *   - getUsageAnalytics is TENANT-FACING and carries no provider cost at all.
 *   - getMarginSummary et al are INTERNAL and are entirely about cost.
 *
 * §15: "Do not expose internal provider costs to customers." The last test in
 * this file is the one that enforces that boundary; everything else checks the
 * arithmetic.
 */
import { getUsageAnalytics } from "@/lib/services/sms-analytics.service";
import { smsMarginService } from "@/lib/services/sms-margin.service";
import {
  addOrganizationSmsCredits,
  setOrganizationSmsRate,
} from "@/lib/services/billing.service";
import { POST as orgTopUpPost } from "@/app/api/admin/organization/sms-credits/route";
import { POST as adminTopUpPost } from "@/app/api/admin/organizations/[id]/sms-credits/route";
import { POST as adminSetRatePost } from "@/app/api/admin/organizations/[id]/sms-rate/route";
import { createTestGroup, createTestOrganization } from "./helpers/fixtures";
import { resetDatabase } from "./helpers/cleanup";
import { rawQuery } from "./helpers/db";
import { backofficeHeaders, buildRequest } from "./helpers/request";

/** A purchase at a given rate, `daysAgo` in the past. */
async function purchase(
  groupId: string,
  credits: number,
  rate: number,
  daysAgo = 0,
) {
  await rawQuery(
    `INSERT INTO sms_credits
       (group_id, billing_account_id, amount_paid, credits_added, remaining_credits,
        rate_applied, created_at)
     SELECT $1, ba.id, $2, $3, $3, $4, NOW() - ($5 || ' days')::interval
     FROM billing_accounts ba WHERE ba.group_id = $1`,
    [
      groupId,
      (credits * rate).toFixed(2),
      credits.toFixed(2),
      rate.toFixed(4),
      daysAgo,
    ],
  );
  await rawQuery(
    `UPDATE billing_accounts SET sms_credits = sms_credits + $1 WHERE group_id = $2`,
    [credits.toFixed(2), groupId],
  );
}

/** A settled (consumed) message, optionally attributed to a feature. */
async function consumed(
  groupId: string,
  credits: number,
  opts: { feature?: string | null; daysAgo?: number } = {},
) {
  await rawQuery(
    `INSERT INTO sms_usage_logs
       (group_id, recipient_phone, message_text, status, credits_deducted,
        payer_type, billing_state, credits_reserved, credits_from_allowance,
        notification_type, settled_at, created_at)
     VALUES ($1,'254700000001','t','sent',$2,'group','consumed',0,0,$3,
             NOW() - ($4 || ' days')::interval, NOW() - ($4 || ' days')::interval)`,
    [groupId, credits.toFixed(4), opts.feature ?? null, opts.daysAgo ?? 0],
  );
  await rawQuery(
    `UPDATE billing_accounts SET sms_credits = GREATEST(sms_credits - $1, 0) WHERE group_id = $2`,
    [credits.toFixed(4), groupId],
  );
}

describe("SMS usage analytics (§8)", () => {
  let groupId: string;

  beforeEach(async () => {
    await resetDatabase();
    ({ groupId } = await createTestGroup("chairperson"));
    await rawQuery(
      `UPDATE billing_accounts SET sms_credits = 0 WHERE group_id = $1`,
      [groupId],
    );
  });

  it("reports purchases, consumption and balance", async () => {
    await purchase(groupId, 1000, 0.9);
    await consumed(groupId, 40);

    const a = await getUsageAnalytics(groupId);
    expect(a.creditsPurchased).toBe(1000);
    expect(a.creditsConsumed).toBe(40);

    // balance = purchased remaining + UNUSED PLAN ALLOWANCE. It used to be
    // purchased only, which is why a group on a plan it had never topped up
    // saw a balance of 0 and a "very low balance" alarm while holding a full
    // allowance it could spend. The fixture group's subscription carries the
    // default 50, none of it used.
    expect(a.purchasedBalance).toBe(960);
    expect(a.allowanceRemaining).toBe(50);
    expect(a.balance).toBe(1010);
  });

  it("separates this month from last month", async () => {
    await purchase(groupId, 1000, 0.9);
    await consumed(groupId, 10, { daysAgo: 0 });
    await consumed(groupId, 25, { daysAgo: 45 }); // safely in a prior month

    const a = await getUsageAnalytics(groupId);
    expect(a.usageThisMonth).toBe(10);
    // 45 days back can be two months ago depending on where in the month we
    // are, so assert only that it is not counted as current.
    expect(a.usageThisMonth).not.toBe(35);
  });

  it("counts only consumed messages, never reserved or released ones", async () => {
    // A reservation is not a spend, and a release never was. Counting either
    // would tell a customer they had used credits they still hold.
    await purchase(groupId, 100, 0.9);
    await rawQuery(
      `INSERT INTO sms_usage_logs
         (group_id, recipient_phone, message_text, status, credits_deducted,
          payer_type, billing_state, credits_reserved, credits_from_allowance)
       VALUES ($1,'254700000002','t','queued',0,'group','reserved',5,0),
              ($1,'254700000003','t','failed',0,'group','released',0,0)`,
      [groupId],
    );

    const a = await getUsageAnalytics(groupId);
    expect(a.creditsConsumed).toBe(0);
  });

  it("projects burn rate and days remaining once there is usage", async () => {
    await purchase(groupId, 1000, 0.9);
    // 300 credits over the trailing 30-day window => 10/day.
    for (let i = 0; i < 3; i++) await consumed(groupId, 100, { daysAgo: i });

    const a = await getUsageAnalytics(groupId);
    expect(a.projectedMonthly).toBeCloseTo(300, 0); // 10/day * 30
    // 700 purchased + 50 unused allowance = 750 spendable, at 10/day.
    // The runway now counts the allowance because the group can genuinely
    // send with it; excluding it under-reported how long they could keep going.
    expect(a.daysRemaining).toBe(75);
  });

  it("reports no projection for a group that has never sent, rather than zero days", async () => {
    // "0 days remaining" on an idle group reads as an alarm. Null says
    // "nothing to project from", which is the truth.
    await purchase(groupId, 500, 0.9);

    const a = await getUsageAnalytics(groupId);
    expect(a.projectedMonthly).toBeNull();
    expect(a.daysRemaining).toBeNull();
  });

  it("breaks usage down by feature and flags unattributed history", async () => {
    await purchase(groupId, 1000, 0.9);
    await consumed(groupId, 30, { feature: "contribution_nudge" });
    await consumed(groupId, 20, { feature: "birthday" });
    await consumed(groupId, 50, { feature: null }); // predates attribution

    const a = await getUsageAnalytics(groupId);
    const byFeature = Object.fromEntries(
      a.byFeature.map((f) => [f.feature ?? "null", f.credits]),
    );
    expect(byFeature["contribution_nudge"]).toBe(30);
    expect(byFeature["birthday"]).toBe(20);

    // ~95% of real production rows have no notification_type because the
    // column postdates them. The UI has to say "unattributed" rather than
    // implying those sends were free or deliberately uncategorised.
    expect(a.hasUnattributedHistory).toBe(true);
    expect(byFeature["null"]).toBe(50);
  });

  it("costs usage at the GROUP'S rate, which is what they pay", async () => {
    await purchase(groupId, 1000, 0.9);
    await consumed(groupId, 100);

    const a = await getUsageAnalytics(groupId);
    // createTestGroup provisions a 0.90 subscription.
    expect(a.costThisMonth).toBeCloseTo(90, 2);
  });
});

/**
 * Restore the pricing/cost configuration migration 143 seeds.
 *
 * sms_provider_costs and sms_pricing_tiers are CONFIGURATION, so
 * resetDatabase() does not truncate them — which means a test that retires a
 * cost or adds a tier leaks that change into every later test, into other
 * suites, and into the next run. The pricing suite learned this the hard way;
 * this file mutates both, so it cleans up after itself explicitly.
 */
async function restorePricingConfig(): Promise<void> {
  await rawQuery(`DELETE FROM sms_pricing_tiers WHERE name = 'Underwater'`);
  await rawQuery(
    `DELETE FROM sms_provider_costs WHERE provider = 'textsms' AND unit_cost <> 0.3500`,
  );
  await rawQuery(
    `UPDATE sms_provider_costs
     SET effective_from = CURRENT_DATE - 365, effective_to = NULL, unit_cost = 0.3500
     WHERE provider = 'textsms'`,
  );
}

describe("SMS margin reporting (§15)", () => {
  let groupId: string;

  beforeEach(async () => {
    await resetDatabase();
    ({ groupId } = await createTestGroup("chairperson"));
    await rawQuery(
      `UPDATE billing_accounts SET sms_credits = 0 WHERE group_id = $1`,
      [groupId],
    );
    await restorePricingConfig();
  });

  afterAll(restorePricingConfig);

  it("computes revenue, cost and margin from real purchases", async () => {
    await purchase(groupId, 1000, 0.9); // KES 900 revenue, 1000 credits

    const m = await smsMarginService.getMarginSummary();
    expect(m.creditsSold).toBe(1000);
    expect(m.revenue).toBeCloseTo(900, 2);
    expect(m.providerCost).toBeCloseTo(350, 2); // 1000 * 0.35
    expect(m.grossMargin).toBeCloseTo(550, 2);
    expect(m.marginPct).toBeCloseTo(61.1, 1);
  });

  it("prices each lot against the cost in force WHEN IT WAS SOLD", async () => {
    // The whole reason sms_provider_costs carries validity dates. If margin
    // used a single current cost, every provider price change would silently
    // restate history — the same mistake §4 forbids on the revenue side.
    await rawQuery(
      `UPDATE sms_provider_costs SET effective_to = CURRENT_DATE - 10 WHERE provider = 'textsms'`,
    );
    await rawQuery(
      `INSERT INTO sms_provider_costs (provider, unit_cost, effective_from)
       VALUES ('textsms', 0.5000, CURRENT_DATE - 9)`,
    );

    await purchase(groupId, 100, 0.9, 20); // sold under the OLD 0.35 cost
    await purchase(groupId, 100, 0.9, 1); // sold under the NEW 0.50 cost

    const m = await smsMarginService.getMarginSummary();
    // 100*0.35 + 100*0.50 = 85, not 200*0.50 = 100 nor 200*0.35 = 70.
    expect(m.providerCost).toBeCloseTo(85, 2);
  });

  it("counts revenue but flags credits sold with no recorded cost", async () => {
    // Understating cost overstates margin. Surfacing the gap beats silently
    // producing a number that looks better than reality.
    await rawQuery(
      `UPDATE sms_provider_costs SET effective_from = CURRENT_DATE - 1 WHERE provider = 'textsms'`,
    );
    await purchase(groupId, 200, 0.9, 30); // predates any recorded cost

    const m = await smsMarginService.getMarginSummary();
    expect(m.revenue).toBeCloseTo(180, 2); // revenue still counted
    expect(m.creditsWithoutCost).toBe(200); // and the gap is visible
  });

  it("returns null margin percentage on no revenue, not zero", async () => {
    const m = await smsMarginService.getMarginSummary();
    expect(m.revenue).toBe(0);
    expect(m.marginPct).toBeNull(); // 0% would read as "we lost everything"
  });

  it("ranks customers by revenue", async () => {
    await purchase(groupId, 1000, 0.9);
    const top = await smsMarginService.getTopCustomers();
    expect(top[0].groupId).toBe(groupId);
    expect(top[0].revenue).toBeCloseTo(900, 2);
    expect(top[0].grossMargin).toBeCloseTo(550, 2);
  });

  it("still lists a group that has only ever sent on its bundled allowance, never bought a top-up", async () => {
    // Regression guard for the INNER JOIN bug: a group with zero sms_credits
    // rows used to vanish from this report entirely, even with real
    // consumption — visible usage, invisible revenue line.
    await consumed(groupId, 5); // no purchase() call at all

    const rows = await smsMarginService.getTopCustomers();
    const mine = rows.find((r) => r.groupId === groupId);
    expect(mine).toBeDefined();
    expect(mine!.revenue).toBe(0);
    expect(mine!.creditsSold).toBe(0);
    expect(mine!.creditsConsumed).toBe(5);
  });

  it("reports per-organization SMS consumption, separate from the group axis", async () => {
    const { organizationId } = await createTestOrganization();
    await rawQuery(
      `INSERT INTO sms_usage_logs
         (group_id, recipient_phone, message_text, status, credits_deducted,
          payer_type, payer_organization_id, billing_state, credits_reserved, credits_from_allowance)
       VALUES ($1,'254700000009','t','sent',15,'organization',$2,'consumed',0,0)`,
      [groupId, organizationId],
    );
    await rawQuery(
      `INSERT INTO organization_billing_accounts (organization_id, sms_credits)
       VALUES ($1, 40)
       ON CONFLICT (organization_id) DO UPDATE SET sms_credits = EXCLUDED.sms_credits`,
      [organizationId],
    );

    const rows = await smsMarginService.getOrganizationUsage();
    const mine = rows.find((r) => r.organizationId === organizationId);
    expect(mine).toBeDefined();
    expect(mine!.creditsConsumed).toBe(15);
    expect(mine!.currentBalance).toBe(40);
    // This org has never had a top-up recorded (see the describe block below
    // for the real-purchase case) — revenue/creditsPurchased must read as a
    // genuine zero, not silently omit the field.
    expect(mine!.revenue).toBe(0);
    expect(mine!.creditsPurchased).toBe(0);
  });

  it("identifies which price bands clear the provider cost", async () => {
    const tiers = await smsMarginService.getTierViability();
    const floor = tiers.find((t) => t.unitPrice === 0.5);

    // §19 warned not to assume 0.50 is sustainable. At a 0.35 cost it is —
    // 30% gross — so it is viable, not loss-making.
    expect(floor).toBeDefined();
    expect(floor!.lossMaking).toBe(false);
    expect(floor!.marginPct).toBeCloseTo(30, 1);

    // Inactive bands are evaluated too: the point is to know a band is viable
    // BEFORE switching to it.
    expect(tiers.some((t) => !t.isActive)).toBe(true);
  });

  it("marks a band that sells at or below cost as loss-making", async () => {
    await rawQuery(
      `INSERT INTO sms_pricing_tiers (name, min_credits, max_credits, unit_price, is_active)
       VALUES ('Underwater', 0, 100, 0.3000, false)`,
    );
    const tiers = await smsMarginService.getTierViability();
    expect(tiers.find((t) => t.name === "Underwater")!.lossMaking).toBe(true);
  });

  it("NEVER leaks provider cost into the tenant-facing surface (§15)", async () => {
    // The boundary this whole split exists to hold. If a cost field ever
    // appears here, a customer can read what Kitabu Yetu pays.
    await purchase(groupId, 1000, 0.9);
    await consumed(groupId, 100);

    const a = await getUsageAnalytics(groupId);
    const serialised = JSON.stringify(a);

    expect(serialised).not.toMatch(/providerCost|unit_cost|unitCost|margin/i);
    expect(Object.keys(a)).not.toContain("providerCost");
    // 0.35 is the provider cost; 90 (100 * the group's own 0.90) is theirs to see.
    expect(serialised).not.toContain("0.35");
    expect(a.costThisMonth).toBeCloseTo(90, 2);
  });
});

describe("Organization SMS credit top-ups", () => {
  let organizationId: string, coordinatorId: string;

  beforeEach(async () => {
    await resetDatabase();
    ({ organizationId, coordinatorId } = await createTestOrganization());
  });
  afterAll(async () => {
    await resetDatabase();
  });

  it("credits the right amount at the default rate, and writes a real purchase ledger row", async () => {
    // No prior organization_billing_accounts row — proves the lazy bootstrap.
    const result = await addOrganizationSmsCredits(
      organizationId,
      900,
      coordinatorId,
    );

    // Manual top-up: no paymentId, so the G27 duplicate guard can never
    // swallow it and a null return would be a real defect.
    expect(result).not.toBeNull();
    if (!result) throw new Error("unreachable: manual top-up returned null");

    expect(result.rateApplied).toBeCloseTo(0.9, 4); // schema default
    expect(result.creditsAdded).toBeCloseTo(1000, 4); // 900 / 0.90
    expect(result.newBalance).toBeCloseTo(1000, 4);

    const [account] = await rawQuery<{ sms_credits: string }>(
      `SELECT sms_credits FROM organization_billing_accounts WHERE organization_id = $1`,
      [organizationId],
    );
    expect(Number(account.sms_credits)).toBeCloseTo(1000, 4);

    const [lot] = await rawQuery<{
      amount_paid: string;
      credits_added: string;
      rate_applied: string;
    }>(
      `SELECT amount_paid, credits_added, rate_applied FROM organization_sms_credits WHERE organization_id = $1`,
      [organizationId],
    );
    expect(Number(lot.amount_paid)).toBeCloseTo(900, 2);
    expect(Number(lot.credits_added)).toBeCloseTo(1000, 4);

    const [ledger] = await rawQuery<{
      payer_type: string;
      entry_type: string;
      amount: string;
    }>(
      `SELECT payer_type, entry_type, amount FROM sms_credit_ledger
       WHERE organization_id = $1 AND entry_type = 'purchase'`,
      [organizationId],
    );
    expect(ledger.payer_type).toBe("organization");
    expect(Number(ledger.amount)).toBeCloseTo(1000, 4);
  });

  it("a changed rate applies to the NEXT top-up, not the last one", async () => {
    const first = await addOrganizationSmsCredits(
      organizationId,
      900,
      coordinatorId,
    ); // at 0.90
    if (!first) throw new Error("unreachable: manual top-up returned null");
    expect(first.rateApplied).toBeCloseTo(0.9, 4);

    await setOrganizationSmsRate(organizationId, 0.5, coordinatorId);
    const second = await addOrganizationSmsCredits(
      organizationId,
      500,
      coordinatorId,
    ); // at 0.50
    if (!second) throw new Error("unreachable: manual top-up returned null");

    expect(second.rateApplied).toBeCloseTo(0.5, 4);
    expect(second.creditsAdded).toBeCloseTo(1000, 4); // 500 / 0.50

    // The first lot's OWN rate_applied must still read 0.90 — a rate change
    // must never restate a completed purchase, same rule §4 already enforces
    // for groups (migration 146).
    const lots = await rawQuery<{ rate_applied: string }>(
      `SELECT rate_applied FROM organization_sms_credits WHERE organization_id = $1 ORDER BY created_at ASC`,
      [organizationId],
    );
    expect(Number(lots[0].rate_applied)).toBeCloseTo(0.9, 4);
    expect(Number(lots[1].rate_applied)).toBeCloseTo(0.5, 4);
  });

  it("setOrganizationSmsRate writes an audit_logs row with old and new values", async () => {
    await setOrganizationSmsRate(organizationId, 1.2, coordinatorId);

    const [audit] = await rawQuery<{
      old_values: { sms_rate: string };
      new_values: { sms_rate: string };
    }>(
      `SELECT old_values, new_values FROM audit_logs
       WHERE action = 'organization.sms_rate_update' AND resource_id = $1`,
      [organizationId],
    );
    expect(Number(audit.old_values.sms_rate)).toBeCloseTo(0.9, 4); // the bootstrapped default
    expect(Number(audit.new_values.sms_rate)).toBeCloseTo(1.2, 4);
  });

  it("rejects a non-positive top-up amount", async () => {
    await expect(
      addOrganizationSmsCredits(organizationId, 0, coordinatorId),
    ).rejects.toThrow();
    await expect(
      addOrganizationSmsCredits(organizationId, -50, coordinatorId),
    ).rejects.toThrow();
  });

  it("getOrganizationUsage() shows real, nonzero revenue once a top-up exists", async () => {
    await addOrganizationSmsCredits(organizationId, 900, coordinatorId, {
      reference: "bank-ref-1",
    });

    const rows = await smsMarginService.getOrganizationUsage();
    const mine = rows.find((r) => r.organizationId === organizationId);
    expect(mine).toBeDefined();
    expect(mine!.revenue).toBeCloseTo(900, 2);
    expect(mine!.creditsPurchased).toBeCloseTo(1000, 4);
    expect(mine!.currentBalance).toBeCloseTo(1000, 4);
  });

  it("an organization_coordinator can self-serve top up their OWN org via the route", async () => {
    const res = await orgTopUpPost(
      buildRequest("/api/admin/organization/sms-credits", {
        method: "POST",
        headers: backofficeHeaders({
          userId: coordinatorId,
          platformRole: "organization_coordinator",
          organizationId,
        }),
        body: { amountKes: 450 },
      }),
    );
    expect(res.status).toBe(201);

    const [account] = await rawQuery<{ sms_credits: string }>(
      `SELECT sms_credits FROM organization_billing_accounts WHERE organization_id = $1`,
      [organizationId],
    );
    expect(Number(account.sms_credits)).toBeCloseTo(500, 4); // 450 / 0.90
  });

  it("a coordinator WITHOUT an organizationId claim is denied on the self-serve route", async () => {
    const res = await orgTopUpPost(
      buildRequest("/api/admin/organization/sms-credits", {
        method: "POST",
        headers: backofficeHeaders({
          userId: coordinatorId,
          platformRole: "organization_coordinator",
        }),
        body: { amountKes: 450 },
      }),
    );
    expect(res.status).toBe(403);
  });

  it("super_admin can grant/correct ANY organization's balance via the by-id route", async () => {
    const res = await adminTopUpPost(
      buildRequest(`/api/admin/organizations/${organizationId}/sms-credits`, {
        method: "POST",
        headers: backofficeHeaders({
          userId: coordinatorId,
          platformRole: "super_admin",
        }),
        body: { amountKes: 900, notes: "goodwill grant" },
      }),
      { params: Promise.resolve({ id: organizationId }) },
    );
    expect(res.status).toBe(201);

    const [account] = await rawQuery<{ sms_credits: string }>(
      `SELECT sms_credits FROM organization_billing_accounts WHERE organization_id = $1`,
      [organizationId],
    );
    expect(Number(account.sms_credits)).toBeCloseTo(1000, 4);
  });

  it("a support-role caller is denied on both super_admin SMS-billing routes — support is read-only", async () => {
    const topUp = await adminTopUpPost(
      buildRequest(`/api/admin/organizations/${organizationId}/sms-credits`, {
        method: "POST",
        headers: backofficeHeaders({
          userId: coordinatorId,
          platformRole: "support",
        }),
        body: { amountKes: 900 },
      }),
      { params: Promise.resolve({ id: organizationId }) },
    );
    expect(topUp.status).toBe(403);

    const setRate = await adminSetRatePost(
      buildRequest(`/api/admin/organizations/${organizationId}/sms-rate`, {
        method: "POST",
        headers: backofficeHeaders({
          userId: coordinatorId,
          platformRole: "support",
        }),
        body: { rate: 1.5 },
      }),
      { params: Promise.resolve({ id: organizationId }) },
    );
    expect(setRate.status).toBe(403);
  });
});
