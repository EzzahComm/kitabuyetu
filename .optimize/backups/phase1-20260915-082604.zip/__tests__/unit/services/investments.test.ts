/**
 * Investment portfolio summary.
 *
 * Regression cover for a summary that read KES 0 and a flat -100% ROI on a
 * perfectly healthy portfolio. Two facts about the module combine to cause it:
 * create() writes status='pending_approval' and only a PATCH moves a row to
 * 'active', and current_value stays NULL until someone records a revaluation.
 * A summary that filtered the value sum to status='active' and summed raw
 * current_value therefore measured an empty set against a real principal —
 * (0 - principal) / principal = -100%, shown to the group in red.
 */
import { withDb } from "@/lib/db";
import {
  investmentsService,
  RecordReturnSchema,
} from "@/lib/services/investments.service";

jest.mock("@/lib/db", () => ({
  withDb: jest.fn(),
  withTransaction: jest.fn(),
  withAdminDb: jest.fn(),
}));

const mockQuery = jest.fn();
const mockClient = { query: mockQuery };

beforeEach(() => {
  mockQuery.mockReset();
  (withDb as jest.Mock).mockImplementation((_ctx, fn) => fn(mockClient));
});

const ctx = { groupId: "g1", userId: "u1", role: "treasurer" };

/** pg hands back `numeric` as a string — mirror that, it is half the bug. */
const summaryRow = (o: Record<string, string>) => ({
  rows: [
    {
      total_investments: "1",
      active_count: "0",
      held_count: "1",
      revalued_count: "0",
      total_principal: "0",
      total_current_value: "0",
      total_returns: "0",
      total_expenses: "0",
      ...o,
    },
  ],
});

describe("investmentsService.getSummary", () => {
  it("reports 0% ROI, not -100%, for a recorded investment awaiting approval", async () => {
    // One pending_approval holding, never revalued. The fixed query carries it
    // at cost, so value == principal and the group is flat, not wiped out.
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "100000",
        total_returns: "0",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.totalCurrentValue).toBe(100000);
    expect(s.roi).toBe(0);
  });

  it("values the portfolio over every status except cancelled, falling back to cost", async () => {
    mockQuery.mockResolvedValueOnce(summaryRow({}));
    await investmentsService.getSummary(ctx);
    const sql = (mockQuery.mock.calls[0][0] as string).replace(/\s+/g, " ");

    // The two specific regressions. Either one alone reproduces the bug.
    expect(sql).not.toMatch(
      /SUM\(current_value\) FILTER \(WHERE status='active'\)/,
    );
    expect(sql).toMatch(/COALESCE\(current_value, principal_amount\)/);
    expect(sql).toMatch(/FILTER \(WHERE status<>'cancelled'\)/);
  });

  it("counts gains and returns into ROI", async () => {
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "120000",
        total_returns: "5000",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.roi).toBe(25); // (120000 + 5000 - 100000) / 100000
  });

  it("still reports a real loss as a loss", async () => {
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "80000",
        total_returns: "0",
      }),
    );

    expect((await investmentsService.getSummary(ctx)).roi).toBe(-20);
  });

  it("subtracts running costs from ROI (migration 156)", async () => {
    // The case the module could not express before expenses existed: an
    // activity returning well that is still behind once its costs are counted.
    // Without the subtraction this reads +25%, which is the overstatement.
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "100000",
        total_returns: "25000",
        total_expenses: "40000",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.totalExpenses).toBe(40000);
    expect(s.roi).toBe(-15); // (100000 + 25000 - 40000 - 100000) / 100000
  });

  it("becomes measurable on an expense alone, with nothing revalued or returned", async () => {
    // A group that has spent on an activity but not yet seen income has real
    // data — a real, negative answer — so ROI must not render as "no data".
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "100000",
        total_returns: "0",
        total_expenses: "10000",
        revalued_count: "0",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.roiMeasurable).toBe(true);
    expect(s.roi).toBe(-10);
  });

  it("never yields NaN when the expenses column is absent", async () => {
    // Number(undefined) is NaN and propagates silently through the ROI
    // arithmetic to a literal "NaN%" on the dashboard.
    const { total_expenses: _omitted, ...withoutExpenses } = summaryRow({
      total_principal: "100000",
      total_current_value: "120000",
    }).rows[0];
    mockQuery.mockResolvedValueOnce({ rows: [withoutExpenses] });

    const s = await investmentsService.getSummary(ctx);

    expect(Number.isNaN(s.roi)).toBe(false);
    expect(s.totalExpenses).toBe(0);
    expect(s.roi).toBe(20);
  });

  it("guards divide-by-zero on the string principal pg returns", async () => {
    // `'0' > 0` is false by coercion so the old code happened to work here,
    // but it was comparing a string — pin the behaviour explicitly.
    mockQuery.mockResolvedValueOnce(summaryRow({ total_principal: "0" }));

    const s = await investmentsService.getSummary(ctx);

    expect(s.roi).toBe(0);
    expect(Number.isNaN(s.roi)).toBe(false);
  });

  // A 0% ROI is arithmetically correct when everything is carried at cost, but
  // it reads as a measurement rather than as "nothing has been measured yet".
  // roiMeasurable is what lets the UI show a dash instead.
  it("reports ROI as not measurable when nothing is revalued and no returns exist", async () => {
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "100000",
        revalued_count: "0",
        total_returns: "0",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.roi).toBe(0);
    expect(s.roiMeasurable).toBe(false);
  });

  it("becomes measurable once a holding is revalued", async () => {
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "100000",
        revalued_count: "1",
        total_returns: "0",
      }),
    );

    // Still 0%, but now that is a real answer: someone revalued it at cost.
    const s = await investmentsService.getSummary(ctx);

    expect(s.roi).toBe(0);
    expect(s.roiMeasurable).toBe(true);
  });

  it("becomes measurable on a return alone, with nothing revalued", async () => {
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_principal: "100000",
        total_current_value: "100000",
        revalued_count: "0",
        total_returns: "5000",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.roi).toBe(5);
    expect(s.roiMeasurable).toBe(true);
  });

  it("is not measurable when there are no investments at all", async () => {
    // COUNT/COALESCE always return a row, so an empty group looks like zeroes
    // rather than no row — guard against a 0/0 ROI being called measurable.
    mockQuery.mockResolvedValueOnce(
      summaryRow({
        total_investments: "0",
        held_count: "0",
        total_principal: "0",
      }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.roi).toBe(0);
    expect(s.roiMeasurable).toBe(false);
  });

  it("exposes heldCount alongside activeCount", async () => {
    mockQuery.mockResolvedValueOnce(
      summaryRow({ active_count: "2", held_count: "5" }),
    );

    const s = await investmentsService.getSummary(ctx);

    expect(s.activeCount).toBe(2);
    expect(s.heldCount).toBe(5);
  });
});

describe("RecordReturnSchema", () => {
  it.each(["dividend", "interest", "capital_gain", "rental_income", "other"])(
    "accepts %s, a real member of public.return_type",
    (returnType) => {
      const parsed = RecordReturnSchema.safeParse({
        returnType,
        amount: 1000,
        returnDate: "2026-08-24",
      });
      expect(parsed.success).toBe(true);
    },
  );

  it("rejects coupon, which is not in the DB enum and failed at INSERT", () => {
    const parsed = RecordReturnSchema.safeParse({
      returnType: "coupon",
      amount: 1000,
      returnDate: "2026-08-24",
    });
    expect(parsed.success).toBe(false);
  });
});
