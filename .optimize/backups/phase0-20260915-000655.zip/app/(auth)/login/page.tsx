'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';
import { Eye, EyeOff } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth, isTenantUser } from '@/lib/auth/context';
import { authApi } from '@/lib/api/endpoints';
import { configureApiClient, ApiError } from '@/lib/api/client';
import { getErrorMessage } from '@/lib/utils';
import { resolvePostLoginPath } from '@/lib/auth/post-login-path';
import { useToast } from '@/hooks/use-toast';
import { isGroupSelectionNeeded } from '@/types/api.types';
import type { NeedsGroupSelection } from '@/types/api.types';

// Mirrors LoginSchema in lib/validators/auth.schema.ts. Phone OR email; no
// group dropdown — the server resolves single-group memberships automatically
// and prompts for selection only when the member is in multiple groups.
const schema = z.object({
  identifier: z.string().min(1, 'Phone number or email is required'),
  password:   z.string().min(1, 'Password is required'),
});
type FormValues = z.infer<typeof schema>;

// "Remember me" only remembers the identifier field for next time — it does
// NOT extend the session. Sessions already persist indefinitely in
// localStorage regardless (lib/auth/context.tsx), so there's no separate
// "stay signed in" behavior to toggle without touching that shared, security
// -relevant storage logic. This key is unrelated to the auth session key.
const REMEMBERED_IDENTIFIER_KEY = 'ky_remembered_identifier';

export default function LoginPage() {
  const router = useRouter();
  const { login, user } = useAuth();
  const { toast } = useToast();

  // When the member is in multiple groups, the API responds with this list
  // and we render a chooser instead of redirecting.
  const [pendingGroups, setPendingGroups] = useState<NeedsGroupSelection['groups'] | null>(null);
  const [submitting,    setSubmitting]    = useState(false);
  const [showPassword,  setShowPassword]  = useState(false);
  const [rememberMe,    setRememberMe]    = useState(false);

  const { register, handleSubmit, getValues, setValue, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  useEffect(() => {
    // Already signed in and landed on /login. Resolve entitlements so a
    // reminder-only group is not bounced into a Kitabu Yetu shell it cannot use.
    if (user) {
      void resolvePostLoginPath(isTenantUser(user) ? user.groupRole : undefined)
        .then((path) => router.replace(path));
    }
  }, [user, router]);

  useEffect(() => {
    configureApiClient({ getToken: () => null, onUnauthorized: () => {} });
  }, []);

  // Pre-fill from a previously remembered identifier, if any.
  useEffect(() => {
    const remembered = localStorage.getItem(REMEMBERED_IDENTIFIER_KEY);
    if (remembered) {
      setValue('identifier', remembered);
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setRememberMe(true);
    }
  }, [setValue]);

  // Shared submit — pass `groupCode` to disambiguate after the user picks a group.
  const submitWith = async (values: FormValues, groupCode?: string) => {
    setSubmitting(true);
    try {
      const result = await authApi.login({ ...values, groupCode });
      if (isGroupSelectionNeeded(result)) {
        setPendingGroups(result.groups);
        return;
      }
      if (rememberMe) localStorage.setItem(REMEMBERED_IDENTIFIER_KEY, values.identifier);
      else            localStorage.removeItem(REMEMBERED_IDENTIFIER_KEY);
      login(result);
      router.push(await resolvePostLoginPath(result.member.groupRole));
    } catch (err) {
      const code = err instanceof ApiError ? ` (${err.code})` : '';
      toast({
        variant:     'destructive',
        title:       'Sign in failed',
        description: `${getErrorMessage(err)}${code}`,
      });
    } finally {
      setSubmitting(false);
    }
  };

  const onPickGroup = (groupCode: string) => {
    void submitWith(getValues(), groupCode);
  };

  // ── Multi-group chooser ────────────────────────────────────────────────
  if (pendingGroups) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Choose a group</CardTitle>
          <CardDescription>
            You belong to {pendingGroups.length} groups. Pick the one you want to sign into.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {pendingGroups.map((g) => (
            <button
              key={g.groupCode}
              type="button"
              onClick={() => onPickGroup(g.groupCode)}
              disabled={submitting}
              className="w-full text-left rounded-lg border border-input bg-background hover:bg-accent hover:border-brand-500 transition-colors px-4 py-3 disabled:opacity-50"
            >
              <p className="text-sm font-semibold text-brand-blue-500">{g.groupName}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {g.groupCode} · {g.officerRole ?? g.groupRole.replace('_', ' ')}
              </p>
            </button>
          ))}
          <button
            type="button"
            onClick={() => setPendingGroups(null)}
            className="text-sm text-muted-foreground hover:text-brand-blue-500 mt-2"
          >
            ← Back to sign in
          </button>
        </CardContent>
      </Card>
    );
  }

  // ── Credentials step ───────────────────────────────────────────────────
  return (
    <Card>
      <CardHeader>
        <CardTitle>Sign in</CardTitle>
        <CardDescription>Use your phone number or email to access your account.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit((v) => submitWith(v))} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="identifier">Phone or email</Label>
            <Input
              id="identifier"
              placeholder="0712345678 or you@example.com"
              autoComplete="username"
              {...register('identifier')}
            />
            {errors.identifier && <p className="text-xs text-destructive">{errors.identifier.message}</p>}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              <Link href="/forgot-password" className="text-xs text-brand-600 hover:underline">
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                className="pr-10"
                {...register('password')}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                tabIndex={-1}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            {errors.password && <p className="text-xs text-destructive">{errors.password.message}</p>}
          </div>

          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="h-4 w-4 rounded border-input"
            />
            Remember my phone/email on this device
          </label>

          <Button type="submit" className="w-full" loading={isSubmitting || submitting}>
            Sign in
          </Button>
        </form>

        <p className="mt-4 text-center text-sm text-muted-foreground">
          Don&apos;t have an account?{' '}
          <Link href="/register" className="text-brand-600 hover:underline font-medium">
            Register your group
          </Link>
        </p>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Organization staff?{' '}
          <Link href="/enterprise/login" className="text-brand-600 hover:underline font-medium">
            Sign in here
          </Link>
          {' '}· Kitabu Yetu team?{' '}
          <Link href="/admin-login" className="text-brand-600 hover:underline font-medium">
            Sign in here
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}
